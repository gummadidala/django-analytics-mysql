'''
Created on 15-Sept-2017

@author: Koteswararao Gummadidala
'''
from django.db import models
from django.utils import timezone
# Create your models here.

class DeskData(models.Model):
    plot = models.CharField(max_length=128)
    cluster = models.CharField(max_length=128)
    count = models.IntegerField()
    date = models.DateField()
    type = models.CharField(max_length=128)
    case_id = models.CharField(max_length=1024,default="")
    class Meta:
        unique_together= (("plot", "cluster", "count", "date", "type","case_id"))