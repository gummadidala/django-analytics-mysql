'''
Created on 15-Sept-2017

@author: Koteswararao Gummadidala
'''
from rest_framework import parsers, renderers
from rest_framework import generics
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST, HTTP_200_OK
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
import django_filters
from rest_framework import filters
from cdets.models import *
from datetime import datetime, timedelta
from dateutil.parser import parse
from cdets.utils import get_cdets_data

class CDETSPlotAPIView(APIView):
    def get(self,request, format=None):
        authentication_classes = (TokenAuthentication,)
        #authentication_classes = (ExpiringTokenAuthentication,)
        res = {}
        datasets = []
        list_query_data = []
        types = []
        plot = request.query_params.get('plot', None)
        cluster = request.query_params.get('cluster', None)
        version = request.query_params.get('version', None)
        start_date = parse(request.query_params.get('start_date',"2017-10-17")).date()
        end_date = parse(request.query_params.get('end_date',datetime.now().date().strftime("%Y-%m-%d"))).date()+timedelta(days=1)
        mavg = request.query_params.get('plot', "False")
        if start_date is None or end_date is None or plot is None:
            return Response({"error":"please provide all mandatory fields like start date, end date and plot!"},status=HTTP_400_BAD_REQUEST)
        if cluster == "ALL":
            cluster= None
        res = get_cdets_data(plot,cluster,start_date,end_date,mavg,version)
        if not res:
            return Response({"error":"Data not found"},status=HTTP_400_BAD_REQUEST)
        else:
            return Response(res,status=HTTP_200_OK)

class CDETSVersionsAPIView(APIView):
    def get(self,request, format=None):
        authentication_classes = (TokenAuthentication,)
        #authentication_classes = (ExpiringTokenAuthentication,)
        username = self.request.user.username
        cluster = request.query_params.get('cluster', None)
        product = request.query_params.get('product', None)
        plot=request.query_params.get('plot', None)
        end_date = datetime.now().date().strftime("%Y-%m-%d")
        start_date =(datetime.now().date() + timedelta(days=-90)).strftime("%Y-%m-%d")
        avail_versions = []
        if cluster is not None:
            cdets_versions = CdetsData.objects.filter(Product=cluster,Submitted_date__gte=start_date, Submitted_date__lte=end_date).values("Version")
        else:
            cdets_versions = CdetsData.objects.filter(Submitted_date__gte=start_date, Submitted_date__lte=end_date).values("Version")
        if cdets_versions is not None and len(cdets_versions)>0:
            for cv in cdets_versions:
                if cv['Version'] not in avail_versions:
                    avail_versions.append(cv['Version'])
        return Response(avail_versions, status = HTTP_200_OK)
