'''
Created on 15-Sept-2017

@author: Koteswararao Gummadidala
'''
from django.db import models

class CdetsData(models.Model):
    Identifier = models.CharField(default="", null=True,blank=True, max_length=255)
    Project = models.CharField(default="", null=True,blank=True, max_length=255)
    Product = models.CharField(default="", null=True,blank=True, max_length=255)
    Submitter = models.CharField(default="", null=True,blank=True, max_length=255)
    Status = models.CharField(default="", null=True,blank=True, max_length=255)
    Severity = models.CharField(default="", null=True,blank=True, max_length=255)
    Submitted_date = models.DateTimeField(null=True,blank=True)
    Component = models.CharField(default="", null=True,blank=True, max_length=255)
    Updated_date = models.DateTimeField(null=True,blank=True)
    Impact = models.CharField(default="", null=True,blank=True, max_length=255)
    Version = models.CharField(default="", null=True,blank=True, max_length=255)
    Attribute = models.TextField(default="", null=True,blank=True)
    Found = models.CharField(default="", null=True,blank=True, max_length=255)
    Count = models.IntegerField()
    Resolved_date = models.DateTimeField(null=True,blank=True)
    Automated_test = models.CharField(default="", null=True,blank=True, max_length=255)
    Bug_origin = models.CharField(default="", null=True,blank=True, max_length=255)
    Dev_escape = models.CharField(default="", null=True,blank=True, max_length=255)