'''
Created on 15-Sept-2017

@author: Koteswararao Gummadidala
'''
from django.conf.urls import url
from cdets import views
urlpatterns = [
                url(r'^api/plotcdets/', views.CDETSPlotAPIView.as_view()),
                url(r'^api/cdetsversions/', views.CDETSVersionsAPIView.as_view()),
            ]