'''
Created on 01-Dec-2017

@author: Koteswararao Gummadidala
'''
from __future__ import division
from cdets.models import *
from random import randint
from datetime import datetime, timedelta
from operator import itemgetter
from django.db.models import Sum, Count, F
from django.db.models import Q

def re_arrange_dates(query_data, label, min_date, max_date):
    avail_dates = []
    for i in query_data:
        try:
            if i['date'] not in avail_dates:
                avail_dates.append(i['date'])
        except:
            return query_data
    ress = []
    for i in query_data:
        ress.append(i)

    while min_date <= max_date:
        if min_date not in avail_dates:
            obj = {}
            obj['date'] = min_date
            obj['call_count'] = 0
            obj["call_info"] = []
            ress.append(obj)
        min_date = min_date + timedelta(days=1)

    sorted_res = sorted(ress, key=lambda x: x['date'])
    for i in sorted_res:
        i["date"] = i["date"].strftime("%b %d %Y")
    dataset = {}
    dates = []
    count = []
    call_infos = []
    for r in sorted_res:
        dates.append(r['date'])
        count.append(r['call_count'])
        if "call_info" in r:
            call_infos.append(r['call_info'])

    dataset['labels'] = dates
    dataset['data'] = count
    dataset['label'] = label
    dataset['call_infos'] = call_infos
    
    return dataset

def Calculate_Moving_Average(data):
    cumsum, moving_aves = [0],[] 
    n = 7
    for i,x in enumerate(data,1):
        cumsum.append(cumsum[i-1] + x)
        if i>=n:
            moving_ave = (cumsum[i] - cumsum[i-n])/n
            moving_aves.append(round(moving_ave,2))
        else:
            moving_aves.append(0)
    obj = {}
    obj['data'] = moving_aves
    obj['label'] = 'MovingAVG'
    return obj          

def get_graph_types(plot):
    graph_types = ["Bar","BarLine","HeatMap","HorizontalBar","Line", "Pie", "Stacked"]
    if plot in ["Defect Outflow"]:
        graph_types = ["Stacked"]
    elif plot in ["Defect Inflow"]:
        graph_types = ["BarLine"]
    else:
        graph_types = ["Pie"]
        
    return graph_types

def get_ylabels():
    yLabel = "Call Count"
    return yLabel

def Cumulative_count(ds, label):
    inc_data = []
    cumSum = 0
    for d in ds['data']:
        cumSum += d
        inc_data.append(cumSum)
    obj = {}
    obj['data'] = inc_data
    obj['label'] = label
    return obj

def get_cdets_filter_fields(plot):
    obj = {}
    if plot == 'Status Distribution':
        obj['col'] = 'Status'
        obj['date'] = 'Submitted_date'
    elif plot == 'Severity Distribution':
        obj['col'] = 'Severity'
        obj['date'] = 'Submitted_date'
    elif plot == 'Found During':
        obj['col'] = 'Found'
        obj['date'] = 'Submitted_date'
    elif plot == 'Component Distribution':
        obj['col'] = 'Component'
        obj['date'] = 'Submitted_date'
    elif plot == 'Impact Distribution':
        obj['col'] = 'Impact'
        obj['date'] = 'Submitted_date'
    elif plot == 'Attribute Distribution':
        obj['col'] = 'Attribute'
        obj['date'] = 'Submitted_date'
    elif plot == 'Defect Inflow':
        obj['col'] = 'Status'
        obj['date'] = 'Submitted_date'
    elif plot == 'Defect Outflow':
        obj['col'] = 'Status'
        obj['date'] = 'Resolved_date'  
    elif plot == 'Automated Test':
        obj['col'] = 'Automated_test'
        obj['date'] = 'Submitted_date' 
    return obj

def get_cdets_pie_data(dataset,cluster,start_date,end_date,typ,col,version):
   
    if version is not None:
        cases_query = CdetsData.objects.filter(**{col: typ}).filter(Version__icontains=version, Product=cluster, Submitted_date__gte=start_date,Submitted_date__lte=end_date).values( "Identifier")
    else:
        cases_query = CdetsData.objects.filter(**{col: typ}).filter(Product=cluster, Submitted_date__gte=start_date, Submitted_date__lte=end_date).values("Identifier")
    
    if cases_query is not None and len(cases_query)>0:
        cases = [a['Identifier'] for a in cases_query]
        dataset["cases"] = typ+': '+', '.join(cases)
    dataset['data'] = [sum(dataset['data'])]
    return dataset

def get_cdets_data(plot,cluster,start_date,end_date,mavg,version):
    res = {}
    datasets = []
    list_query_data = []
    types = []
    graph_types = get_graph_types("CDETS", plot)
    filter = get_cdets_filter_fields(plot)
    d = filter['date']
    f = "date("+d+")"
    
    if plot == "Defect Inflow":
        obj = {}
        if version is None:
            query_res = CdetsData.objects.filter(Product = cluster,Submitted_date__gte = start_date,Submitted_date__lte=end_date).extra({'date':f}).annotate(date=F(d)).values("date").annotate(call_count=Sum("Count"))
        else:
            query_res = CdetsData.objects.filter(Version__icontains=version,Product = cluster,Submitted_date__gte = start_date,Submitted_date__lte=end_date).extra({'date':f}).annotate(date=F(d)).values("date").annotate(call_count=Sum("Count"))
        obj['type'] = "Cases Created Count"
        obj['query_data'] = query_res
        list_query_data.append(obj)
        
    elif plot == "Defect Outflow":
        if version is not None:
            query_res = CdetsData.objects.filter(Product = cluster,Version__icontains=version,Resolved_date__gte=start_date, Resolved_date__lte=end_date).extra({'date':f}).annotate(date=F(d)).values("date").annotate(call_count=Sum("Count"))
        else:
            query_res = CdetsData.objects.filter(Product = cluster,Resolved_date__gte=start_date, Resolved_date__lte=end_date).extra({'date':f}).annotate(date=F(d)).values("date").annotate(call_count=Sum("Count"))
        obj = {}
        obj['type'] = "Cases Resolved Count"
        obj['query_data'] = query_res
        list_query_data.append(obj)
    else:
        if version is not None:
            types_query = CdetsData.objects.filter(Version__icontains=version,Product=cluster,Submitted_date__gte=start_date, Submitted_date__lte=end_date).values(filter['col'])
        else:
            types_query = CdetsData.objects.filter(Product = cluster,Submitted_date__gte=start_date, Submitted_date__lte=end_date).values(filter['col'])
        for q in types_query:
            if q[filter['col']] and q[filter['col']] not in types and q[filter['col']] not in ["?"]:
                types.append(q[filter['col']])
        for typ in types:
            if version is not None:
                query_res = CdetsData.objects.filter(**{filter['col'] : typ}).filter(Product = cluster,Version__icontains=version,Submitted_date__gte=start_date, Submitted_date__lte=end_date).extra({'date':f}).annotate(date=F(d)).values("date").annotate(call_count=Sum("Count"))
            else:
                query_res = CdetsData.objects.filter(**{filter['col'] : typ}).filter(Product = cluster,Submitted_date__gte=start_date, Submitted_date__lte=end_date).extra({'date':f}).annotate(date=F(d)).values("date").annotate(call_count=Sum("Count"))
            obj = {}
            obj['type'] = typ
            obj['query_data'] = query_res
            list_query_data.append(obj)
                                                              
    for q_data in list_query_data: 
        end_date = end_date +timedelta(days=-1)
        res_data = re_arrange_dates(q_data['query_data'], q_data['type'], start_date, end_date,"CDETS", cluster, plot)
        if "Pie" in graph_types:
            end_date = end_date +timedelta(days=1)
            res_data = get_cdets_pie_data(res_data,cluster, start_date, end_date, q_data['type'], filter['col'],version)
        datasets.append(res_data)
    if len(datasets) > 0:
        if mavg == "True":
            datasets.append( Calculate_Moving_Average(datasets[0]['data']))
        if plot == "Defect Inflow":
            datasets.append(Cumulative_count(datasets[0],"Total Count"))
        res['dataset'] = datasets
        res['labels'] = datasets[0]['labels']
        res['graphTypes'] = get_graph_types(plot)
        res['yLabel'] = get_ylabels()
        if graph_types[0] == "Pie":
            res['labels'] = types
    if not res:
        return None
    else:
        return res
