'''
Created on 15-Sept-2017

@author: Koteswararao Gummadidala
'''
from django.conf.urls import url
from hybridtest import views
urlpatterns = [
                url(r'^api/plotdesk/', views.HybridTestPlotAPIView.as_view()),
            ]