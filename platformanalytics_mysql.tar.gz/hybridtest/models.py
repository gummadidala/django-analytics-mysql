'''
Created on 15-Sept-2017

@author: Koteswararao Gummadidala
'''
from django.db import models
from django.utils import timezone
# Create your models here.

class HybridTestData(models.Model):
    date = models.DateTimeField()
    outcome = models.CharField(max_length=255)
    exitcode = models.CharField(max_length=255)
    exitreason = models.CharField(max_length=255)
    calltest = models.CharField(max_length=255)
    calendartest = models.CharField(max_length=255)
    count = models.IntegerField()
    class Meta:
        unique_together= (("date", "outcome", "exitcode", "exitreason", "calltest", "calendartest", "count"))
