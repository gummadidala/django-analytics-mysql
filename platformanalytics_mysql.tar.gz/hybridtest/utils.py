'''
Created on 01-Dec-2017

@author: Koteswararao Gummadidala
'''
from __future__ import division
from hybridtest.models import *
from random import randint
from datetime import datetime, timedelta
from operator import itemgetter
from django.db.models import Sum, Count, F
from django.db.models import Q

def re_arrange_dates(query_data, label, min_date, max_date):
    avail_dates = []
    for i in query_data:
        try:
            if i['date'] not in avail_dates:
                avail_dates.append(i['date'])
        except:
            return query_data
        
    while min_date <= max_date:
        if min_date not in avail_dates:
            obj = {}
            obj['date'] = min_date
            obj['count'] = 0
            obj["call_info"] = []
            query_data.append(obj)
        min_date = min_date + timedelta(days=1)

    sorted_res = sorted(query_data, key=lambda x: x['date'])
    
    for i in sorted_res:
        i["date"] = i["date"].strftime("%b %d %Y")
    
    dataset = {}
    dates = []
    count = []
    for r in sorted_res:
        dates.append(r['date'])
        count.append(r['count'])
        
    dataset['labels'] = dates
    dataset['data'] = count
    dataset['label'] = label
    
    return dataset

def get_graph_types(plot):
    graph_types = ["Stacked","BarLine","HeatMap","HorizontalBar","Line", "Pie", "Bar"]
    return graph_types

def get_ylabels(plot):
    yLabel = "Call Count"
    return yLabel

def get_hybridtest_filter_fields(plot):
    obj = {}
    if plot == "Test Environment Failure":
        obj['field'] = "exitreason"
    elif plot == "CallTest Results":
        obj['field'] = "calltest"
    elif plot == "CalendarTest Results":
        obj['field'] = "calendartest"
    return obj

def get_hybridtest_data(plot,start_date,end_date,mavg):
    res = {}
    datasets = []
    list_query_data = []
    types = []
    filters = get_hybridtest_filter_fields(plot)
    if "type" in filters:
        types_query = HybridTestData.objects.filter(date__gte=start_date, date__lte=end_date).filter(**{filters['col'] : filters['type']}).values(filters['field'])
    else:
        types_query = HybridTestData.objects.filter(date__gte=start_date, date__lte=end_date).values(filters['field'])
    
    for qr in types_query:
        if qr[filters['field']] not in types:
            types.append(qr[filters['field']])
    if "NA" in types:
        types.remove("NA")
    for typ in types:
        if 'col' in filters:
            query_res = HybridTestData.objects.filter(**{filters['field'] : typ}).filter(**{filters['col'] : filters['type']}).filter(date__gte=start_date, date__lte=end_date).extra({'date':"date(date)"}).values("date").annotate(call_count=Sum("count"))
        else:
            query_res = HybridTestData.objects.filter(**{filters['field'] : typ}).filter(date__gte=start_date, date__lte=end_date).extra({'date':"date(date)"}).values("date").annotate(call_count=Sum("count"))
        obj = {}
        obj['type'] = typ
        obj['query_data'] = query_res
        list_query_data.append(obj)
    end_date = end_date +timedelta(days=-1)
    for q_data in list_query_data: 
        res_data = re_arrange_dates(q_data['query_data'], q_data['type'], start_date, end_date)
        datasets.append(res_data)
    
    if len(datasets) > 0:
        res['dataset'] = datasets
        res['labels'] = datasets[0]['labels']
        res['graphTypes'] = get_graph_types(plot)
        res['yLabel'] = get_ylabels(plot)
    if not res:
        return None
    else:
        return res