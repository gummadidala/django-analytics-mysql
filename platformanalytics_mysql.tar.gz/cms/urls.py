'''
Created on 15-Sept-2017

@author: Koteswararao Gummadidala
'''
from django.conf.urls import url
from cms import views
urlpatterns = [
                url(r'^api/plotcms/', views.CMSPlotAPIView.as_view()),
                url(r'^api/cmsversions/', views.CMSVersionsAPIView.as_view()),
            ]