'''
Created on 15-Sept-2017

@author: Koteswararao Gummadidala
'''
from django.db import models
from django.utils import timezone
# Create your models here.

class CmsData(models.Model):
    session = models.CharField(max_length=255)
    correlatorindex = models.IntegerField(default=0, null=True,blank=True)
    unixtime = models.IntegerField()
    callbridge = models.CharField(default="", null=True,blank=True, max_length=255)
    recordindex = models.IntegerField(default=0, null=True,blank=True)
    type = models.CharField(default="", null=True,blank=True, max_length=255) 
    pkid = models.CharField(default="", null=True,blank=True, max_length=255)
    name = models.CharField(default="", null=True,blank=True, max_length=255)
    ownername = models.CharField(default="", null=True,blank=True, max_length=255)
    calltype = models.CharField(default="", null=True,blank=True, max_length=255)
    cospace = models.CharField(default="", null=True,blank=True, max_length=255)
    callcorrelator = models.CharField(default="", null=True,blank=True, max_length=255)
    calllegscompleted = models.IntegerField(default=0, null=True,blank=True)
    calllegsmaxactive = models.IntegerField(default=0, null=True,blank=True)
    durationseconds = models.IntegerField(default=0, null=True,blank=True)
    calllegid = models.CharField(default="", null=True,blank=True, max_length=255)
    remoteparty = models.CharField(default="", null=True,blank=True, max_length=255)
    localaddress = models.CharField(default="", null=True,blank=True, max_length=255)
    displayname = models.CharField(default="", null=True,blank=True, max_length=255)
    remoteaddress = models.CharField(default="", null=True,blank=True, max_length=255)
    calllegtype = models.CharField(default="", null=True,blank=True, max_length=255)
    direction = models.CharField(default="", null=True,blank=True, max_length=255)
    groupid = models.CharField(default="", null=True,blank=True, max_length=255)
    sipcallid = models.CharField(default="", null=True,blank=True, max_length=255)
    callid = models.CharField(default="", null=True,blank=True, max_length=255)
    deactivated = models.CharField(default="", null=True,blank=True, max_length=255)
    reason = models.CharField(default="", null=True,blank=True, max_length=255)
    remoteteardown = models.CharField(default="", null=True,blank=True, max_length=255)
    activatedduration = models.IntegerField(default=0, null=True,blank=True)
    calllegdurationseconds = models.IntegerField(default=0, null=True,blank=True)
    mainvideoviewer = models.DecimalField(max_digits=30,decimal_places=10,default=0,null=True,blank=True)
    mainvideocontributor = models.DecimalField(max_digits=30,decimal_places=10,default=0,null=True,blank=True)
    encryptedmedia = models.CharField(default="", null=True,blank=True, max_length=255)
    rxaudio_codec = models.CharField(default="", null=True,blank=True, max_length=255)
    rxaudio_pktlossbursts_duration = models.DecimalField(max_digits=30,decimal_places=10,default=0,null=True,blank=True)
    rxaudio_pktlossbursts_density = models.DecimalField(max_digits=30,decimal_places=10,default=0,null=True,blank=True)
    rxaudio_pktgap_duration = models.DecimalField(max_digits=30,decimal_places=10,default=0,null=True,blank=True)
    rxaudio_pktgap_density = models.DecimalField(max_digits=30,decimal_places=10,default=0,null=True,blank=True)
    txaudio_codec = models.CharField(default="", null=True,blank=True, max_length=255)
    rxvideo_codec = models.CharField(default="", null=True,blank=True, max_length=255)
    rxvideo_maxsizewidth = models.IntegerField(default=0, null=True,blank=True)
    rxvideo_maxsizeheight = models.IntegerField(default=0, null=True,blank=True)
    rxvideo_pktlossbursts_duration = models.DecimalField(max_digits=30,decimal_places=10,default=0,null=True,blank=True)
    rxvideo_pktlossbursts_density = models.DecimalField(max_digits=30,decimal_places=10,default=0,null=True,blank=True)
    rxvideo_pktgap_duration = models.DecimalField(max_digits=30,decimal_places=10,default=0,null=True,blank=True)
    rxvideo_pktgap_density = models.DecimalField(max_digits=30,decimal_places=10,default=0,null=True,blank=True)
    txvideo_codec = models.CharField(default="", null=True,blank=True, max_length=255)
    txvideo_maxsizewidth = models.IntegerField(default=0, null=True,blank=True)
    txvideo_maxsizeheight = models.IntegerField(default=0, null=True,blank=True)
    modifiedcallbridge = models.CharField(default="", null=True,blank=True, max_length=255)
    date = models.DateTimeField(null=True,blank=True)
    version = models.CharField(default="", null=True,blank=True, max_length=255)
    class Meta:
        unique_together= (("session","correlatorindex"))

class Cmsversion(models.Model):
    CmsServerVersion = models.CharField(default="", null=True, blank=True, max_length=255)
    CmsServerName = models.CharField(default="", null=True, blank=True, max_length=255)
    ChangeDate = models.DateField(default = timezone.now, null=True)
    Category = models.CharField(null=True, blank=True, max_length=255)
    class Meta:
        unique_together= (("CmsServerVersion", "CmsServerName", "ChangeDate", "Category",))