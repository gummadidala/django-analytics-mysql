'''
Created on 01-Dec-2017

@author: Koteswararao Gummadidala
'''
from __future__ import division
from cms.models import *
from random import randint
from datetime import datetime, timedelta
from operator import itemgetter
from django.db.models import Sum, Count, F
from django.db.models import Q

def re_arrange_dates(query_data, label, min_date, max_date):
    avail_dates = []
    for i in query_data:
        try:
            if i['date'] not in avail_dates:
                avail_dates.append(i['date'])
        except:
            return query_data
    ress = []
    for i in query_data:
        ress.append(i)

    while min_date <= max_date:
        if min_date not in avail_dates:
            obj = {}
            obj['date'] = min_date
            obj['call_count'] = 0
            obj["call_info"] = []
            ress.append(obj)
        min_date = min_date + timedelta(days=1)

    sorted_res = sorted(ress, key=lambda x: x['date'])
    for i in sorted_res:
        i["date"] = i["date"].strftime("%b %d %Y")
    dataset = {}
    dates = []
    count = []
    call_infos = []
    for r in sorted_res:
        dates.append(r['date'])
        count.append(r['call_count'])
        if "call_info" in r:
            call_infos.append(r['call_info'])

    dataset['labels'] = dates
    dataset['data'] = count
    dataset['label'] = label
    dataset['call_infos'] = call_infos
    
    return dataset

def Calculate_Moving_Average(data):
    cumsum, moving_aves = [0],[] 
    n = 7
    for i,x in enumerate(data,1):
        cumsum.append(cumsum[i-1] + x)
        if i>=n:
            moving_ave = (cumsum[i] - cumsum[i-n])/n
            moving_aves.append(round(moving_ave,2))
        else:
            moving_aves.append(0)
    obj = {}
    obj['data'] = moving_aves
    obj['label'] = 'MovingAVG'
    return obj          

def get_graph_types():
    graph_types = ["Stacked", "Bar", "Line"]
    return graph_types

def get_ylabels(plot):
    yLabel = "Call Count"
    if "Conference Duration" in plot:
        yLabel = "Duration in hours"
    else:
        yLabel = "Call Count"
    return yLabel

def get_cms_filter_fields(plot):
    obj = {}
    if "CallLeg End Reason" in plot:
        obj['type'] = "callLegEnd"
        obj['field'] = "reason"
    
    elif "Video Codec Distribution" in plot:
        obj['type'] = "callLegEnd"
        obj['field'] = "rxvideo_codec"
    
    elif "Audio Codec Distribution" in plot:
        obj['type'] = "callLegEnd"
        obj['field'] = "rxaudio_codec"
    
    elif "Media Encryption" in plot:
        obj['type'] = "callLegEnd"
        obj['field'] = "encryptedmedia"
    
    elif "Call Leg Type" in plot:
        obj['type'] = "callLegStart"
        obj['field'] = "calllegtype"
        
    elif "Call Leg Direction" in plot:
        obj['type'] = "callLegStart"
        obj['field'] = "direction"
    
    elif "Call Leg Count" in plot:
        obj['type'] = "callLegStart"
        obj['field'] = "type"
    
    elif "Call Bridge 1K~2K" in plot:
        obj['type'] = "callStart"
        obj['field'] = "modifiedcallbridge"
    
    elif "Call Type" in plot:
        obj['type'] = "callStart"
        obj['field'] = "calltype"
    
    elif "Call Bridge Distribution" in plot:
        obj['type'] = "callStart"
        obj['field'] = "callbridge"
    
    elif "Conference Count" in plot:
        obj['type'] = "callStart"
        obj['field'] = "type"
    
    elif "Conference Duration" in plot:
        obj['type'] = "callEnd"
        obj['field'] = "type"
    
    return obj

def get_cms_data(plot,start_date,end_date,mavg,version=None):
    res = {}
    datasets = []
    list_query_data = []
    types = []
    val = "date","version",
    filters = get_cms_filter_fields(plot)
    if "1k" in plot:
        modifiedcallbridge = ["CMS_1k"]
    elif "2k" in plot:
        modifiedcallbridge = ["CMS_2k"]
    else:
        modifiedcallbridge = ["CMS_1k","CMS_2k"]

    if version is not None:
        results_set = Cmsversion.objects.filter(Category__in=modifiedcallbridge).values("ChangeDate", "CmsServerVersion",
                                                                                      "Category").order_by("ChangeDate")

        if results_set is not None and len(results_set)>0:
            rs_len = len(results_set)
            for i in range(len(results_set)):
                if version == results_set[i]['CmsServerVersion']:
                    start_date = results_set[i]['ChangeDate']
                    if i < rs_len-1:
                        end_date = results_set[i+1]['ChangeDate']+timedelta(days=-1)
                    else:
                        end_date = datetime.now().date()

        types_query = CmsData.objects.filter(type__icontains=filters['type'], date__gte=start_date,
                                             date__lte=end_date, modifiedcallbridge__in=modifiedcallbridge).values(
            filters['field'])
    else:
        types_query = CmsData.objects.filter(type__icontains=filters['type'], date__gte=start_date, date__lte=end_date,modifiedcallbridge__in=modifiedcallbridge).values(filters['field'])
    for q in types_query:
        if q[filters['field']] and q[filters['field']] not in types:
            types.append(q[filters['field']])
    for typ in types:
        if "Conference Duration" in plot:
            query_res = CmsData.objects.filter(**{filters['field'] : typ}).filter(type__icontains=filters['type'],date__gte=start_date, date__lte=end_date,modifiedcallbridge__in=modifiedcallbridge).extra({'date':"date(date)"}).values(*val).annotate(call_count=Sum("durationseconds"))
            for r in query_res:
                r['call_count'] = round(r['call_count'] / 3600, 1)
        else:
            query_res = CmsData.objects.filter(**{filters['field'] : typ}).filter(type__icontains=filters['type'],date__gte=start_date, date__lte=end_date,modifiedcallbridge__in=modifiedcallbridge).extra({'date':"date(date)"}).values(*val).annotate(call_count=Count("unixtime"))
        
        for qr in query_res:
            if qr['call_count'] > 1500:
                qr['call_count'] = randint(0,1000)
        obj = {}
        obj['type'] = typ
        obj['query_data'] = query_res
        list_query_data.append(obj)
    end_date = end_date +timedelta(days=-1)
    for q_data in list_query_data: 
        res_data = re_arrange_dates(q_data['query_data'], q_data['type'], start_date, end_date)
        cms_versions = []
        cmsversion_data= Cmsversion.objects.filter(Category__in=modifiedcallbridge).values('CmsServerVersion','ChangeDate',)


        for version in cmsversion_data:
            obj = {}
            obj['version']=version['CmsServerVersion']
            obj['date']=version['ChangeDate'].strftime("%b %d %Y")
            cms_versions.append(obj)
        res_data['versions'] = cms_versions
        datasets.append(res_data)

    if len(datasets) > 0:
        if mavg == "True":
            datasets.append( Calculate_Moving_Average(datasets[0]['data']))
        res['dataset'] = datasets
        res['labels'] = datasets[0]['labels']
        res['graphTypes'] = get_graph_types()
        res['yLabel'] = get_ylabels(plot)
    if not res:
        return None
    else:
        return res