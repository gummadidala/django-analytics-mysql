from __future__ import unicode_literals

from django.db import models
import uuid
from django.contrib.auth.models import Group, User
# Create your models here.

class PreferenceType(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=64)

class PlotType(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=64)

class Cluster(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=64)

class Business(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=64)

class AccountType(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=64)

class Product(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=64)
    clusters = models.ManyToManyField(Cluster)
    plots = models.ManyToManyField(PlotType)
    business = models.ForeignKey(Business, default="", null=True,blank=True)

class DataSourceInformation(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    hostname = models.CharField(max_length=64)
    databasename = models.CharField(max_length=64)
    username = models.CharField(max_length=64)
    password = models.CharField(max_length=64)
    product = models.ForeignKey(Product, default="", null=True,blank=True)

class UserRole(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=64)
    user_groups = models.ManyToManyField(Group)

class AccountUser(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    account_user = models.ForeignKey(User, default="", null=True,blank=True)
    user_roles = models.ManyToManyField(UserRole)
    business = models.ForeignKey(Business, default="", null=True,blank=True)
    account_type = models.ForeignKey(AccountType, default="", null=True,blank=True)

class PreferenceMapping(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    clusters = models.ManyToManyField(Cluster)
    plots = models.ManyToManyField(PlotType)
        
class UserPreferences(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    account_user = models.ForeignKey(AccountUser, default="", null=True,blank=True)
    product = models.ForeignKey(Product, default="", null=True,blank=True)
    pref_mappings = models.ManyToManyField(PreferenceMapping)
    pref_type = models.ForeignKey(PreferenceType,default="", null=True,blank=True)