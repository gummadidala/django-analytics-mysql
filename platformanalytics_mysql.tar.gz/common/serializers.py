'''
Created on 18-Sept-2017

@author: Koteswararao Gummadidala
'''
from rest_framework import serializers
from common.models import *
from django.contrib.auth.models import User, Group, Permission
from __builtin__ import str

class GroupSerializer(serializers.ModelSerializer):
    permissions = serializers.SlugRelatedField(
        queryset=Permission.objects.all(),
        slug_field='codename',
        many=True)
    class Meta:
        model = Group
        fields = ['name','permissions']

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'last_name', 'first_name','email']

class UserRoleSerializer(serializers.ModelSerializer):
    user_groups = serializers.SlugRelatedField(
        queryset=Group.objects.all(),
        slug_field='name',
        many=True)
    class Meta:
        model = UserRole
        fields = ['name','user_groups','key'] 

class AccountUserSerializer(serializers.ModelSerializer):
    account_type = serializers.SlugRelatedField(
        queryset=AccountType.objects.all(),
        slug_field='name')
    business = serializers.SlugRelatedField(
        queryset=Business.objects.all(),
        slug_field='name')
    user_roles = UserRoleSerializer(many = True),
    account_user = UserSerializer()
    class Meta:
        model = AccountUser
        fields = ['key','business','account_type','account_user','user_roles'] 

class AccountTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccountType
        fields = ['key', 'name']

class ClusterSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cluster
        fields = ['key', 'name']

class PlotTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlotType
        fields = ['key', 'name']

class BusinessSerializer(serializers.ModelSerializer):
    class Meta:
        model = Business
        fields = ['key', 'name']

class PreferenceTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = PreferenceType
        fields = ['key', 'name']

class ProductSerializer(serializers.ModelSerializer):
    business = serializers.SlugRelatedField(
        queryset=Business.objects.all(),
        slug_field='name')
    clusters = ClusterSerializer(many=True)
    plots = PlotTypeSerializer(many=True)
    class Meta:
        model = Product
        fields = ['key', 'name', 'clusters', 'plots', 'business']

class ProductShortSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['key', 'name']

class ProductWriteSerializer(serializers.ModelSerializer):
    business = serializers.SlugRelatedField(
        queryset=Business.objects.all(),
        slug_field='key',
        required=False,allow_null=True)
    clusters = serializers.SlugRelatedField(
        queryset=Cluster.objects.all(),
        slug_field='key',many=True,
        required=False,allow_null=True)
    plots = serializers.SlugRelatedField(
        queryset=PlotType.objects.all(),
        slug_field='key',many=True,
        required=False,allow_null=True)
    class Meta:
        model = Product
        fields = ['key', 'name','business','clusters', 'plots']
    
class DataSourceInformationSerializer(serializers.ModelSerializer):
    product = ProductShortSerializer()
    class Meta:
        model = DataSourceInformation
        fields = ['key', 'hostname', 'databasename', 'username', 'password','product']

class DataSourceInformationWriteSerializer(serializers.ModelSerializer):
    product = serializers.SlugRelatedField(
        queryset=Product.objects.all(),
        slug_field='key')
    class Meta:
        model = DataSourceInformation
        fields = ['key', 'hostname', 'databasename', 'username', 'password','product']



class PreferenceMappingSerializer(serializers.ModelSerializer):
    clusters = ClusterSerializer(many=True)
    plots = PlotTypeSerializer(many=True)
    class Meta:
        model = PreferenceMapping
        fields = ['key', 'clusters', 'plots']

class PreferenceMappingWriteSerializer(serializers.ModelSerializer):
    clusters = serializers.SlugRelatedField(
        queryset=Cluster.objects.all(),
        slug_field='key',many=True,
        required=False,allow_null=True)
    plots = serializers.SlugRelatedField(
        queryset=PlotType.objects.all(),
        slug_field='key',many=True,
        required=False,allow_null=True)
    class Meta:
        model = PreferenceMapping
        fields = ['key', 'clusters', 'plots']

class UserPreferencesSerializer(serializers.ModelSerializer):
    account_user = AccountUserSerializer()
    product = ProductShortSerializer()
    pref_mappings = PreferenceMappingSerializer(many=True)
    pref_type = PreferenceTypeSerializer()
    class Meta:
        model = UserPreferences
        fields = ['key','account_user','product', 'pref_mappings', 'pref_type']

class UserPreferencesWriteSerializer(serializers.ModelSerializer):
    account_user = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key',
        required=False,allow_null=True)
    product = serializers.SlugRelatedField(
        queryset=Product.objects.all(),
        slug_field='key',
        required=False,allow_null=True)
    pref_type = serializers.SlugRelatedField(
        queryset=PreferenceType.objects.all(),
        slug_field='name',
        required=False,allow_null=True)
    pref_mappings = serializers.SlugRelatedField(
        queryset=PreferenceMapping.objects.all(),
        slug_field='key',
        required=False,allow_null=True,many=True)
    class Meta:
        model = UserPreferences
        fields = ['key','account_user','product', 'pref_mappings', 'pref_type']