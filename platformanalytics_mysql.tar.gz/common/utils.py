from Crypto.Cipher import AES
import base64
from common.models import *

def decryptPassword(encrypted, passphrase):
    encrypted = base64.b64decode(encrypted)
    IV = encrypted[:16]
    aes = AES.new(passphrase, AES.MODE_CBC, IV)
    data = aes.decrypt(encrypted[16:])
    return data[:-ord(data[-1])]

def create_preference_mappings(prod):
    preference_mappings = []
    if len(prod.clusters.all()) > 0:
        for cluster in prod.clusters.all():
            preference_mappping = PreferenceMapping()
            preference_mappping.save()
            preference_mappping.plots = prod.plots.all()
            preference_mappping.clusters = [cluster]
            preference_mappping.save()
            preference_mappings.append(preference_mappping)
    else:
        preference_mappping = PreferenceMapping()
        preference_mappping.save()
        preference_mappping.plots = prod.plots.all()
        preference_mappping.clusters = prod.clusters.all()
        preference_mappping.save()
        preference_mappings.append(preference_mappping)
        
    return preference_mappings

def create_user_preferences(act_usr):
    prods = Product.objects.all()
    if prods and len(prods)>0:
        for prod in prods:
            user_preference = UserPreferences()
            user_preference.product = prod
            user_preference.pref_type = PreferenceType.objects.filter(name="UI")[0]
            user_preference.account_user = act_usr
            user_preference.save()
            user_preference.pref_mappings = create_preference_mappings(prod)
            user_preference.save()
   