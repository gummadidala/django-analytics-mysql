from __future__ import division
from rest_framework import parsers, renderers
from rest_framework import generics
from rest_framework.authtoken.models import Token
from rest_framework.authtoken.serializers import AuthTokenSerializer
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST, HTTP_200_OK
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
import django_filters
from rest_framework import filters
from django.contrib.auth.models import User
from common.models import *
from common.serializers import *
from random import randint
from datetime import datetime, timedelta
from dateutil.parser import parse
from  ldap3 import Server, Connection, ALL
import traceback,sys
import requests
from Crypto.Cipher import AES
import base64
import os, json
from common.utils import *
         
class ObtainAuthTokenAPIView(APIView):
    def post(self,request):
        server_name = "ldaps://ds.cisco.com:636"
        parsed_data = request.data
        if 'username' not in parsed_data or len(parsed_data['username']) <= 0:
            return Response({"error":"username is required!"}, HTTP_400_BAD_REQUEST)
        if "password" not in parsed_data or len(parsed_data['password']) <= 0:
            return Response({"error":"password is required!"}, HTTP_400_BAD_REQUEST)
        user_name = parsed_data['username']
        password = parsed_data['password']
        if " " in password:
            password = password.replace(" ",'+')
        password = decryptPassword(password, "1234567890123456")
        try:
            s = Server(server_name, get_info=ALL)
            c = Connection(s, user=user_name,password=password)
            if not c.bind():
                return Response({"error":"Invalid credentials!"}, status=HTTP_400_BAD_REQUEST)
            user_obj = User.objects.filter(username=user_name)
            if len(user_obj)==0:
                usr = User()
                usr.first_name=""
                usr.last_name=""
                usr.username = user_name
                usr.date_joined=datetime.now()
                usr.email = ""
                usr.save()
                act_usr = AccountUser()
                act_usr.account_user = usr
                #act_usr.user_roles = []
                act_usr.save()
                token, created = Token.objects.get_or_create(user=usr)
                create_user_preferences(act_usr)
                  
            else:
                token, created = Token.objects.get_or_create(user=user_obj[0])
            token.created = datetime.now()
            token.save()
    
            return Response({'token': token.key}, HTTP_200_OK)
        except:
            return Response({"error":"Please try again!"}, status=HTTP_400_BAD_REQUEST)

class AccountUserAPIView(generics.ListAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = AccountUserSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('account_type__name','account_user__username',)
    search_fields = ('account_user__username',)
    lookup_field = 'key'
    def get_queryset(self):
        '''
        usr = self.request.user.username
        acct_user = AccountUser.objects.filter(account_user__username = usr)
        return acct_user
        '''
        return AccountUser.objects.all()

class BusinessAPIView(generics.ListCreateAPIView):
    #authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    #permission_classes = (IsAuthenticated,)
    serializer_class = BusinessSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return Business.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return BusinessSerializer
        return BusinessSerializer

class BusinessUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = BusinessSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return Business.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return BusinessSerializer
        return BusinessSerializer

class DataSourceInformationAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = DataSourceInformationSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('product__name','product__key',)
    search_fields = ('product__name','product__key',)
    lookup_field = 'key'
    def get_queryset(self):
        return DataSourceInformation.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return DataSourceInformationWriteSerializer
        return DataSourceInformationSerializer

class DataSourceInformationUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = DataSourceInformationSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('product__name','product__key',)
    search_fields = ('product__name','product__key',)
    lookup_field = 'key'
    def get_queryset(self):
        return DataSourceInformation.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return DataSourceInformationWriteSerializer
        return DataSourceInformationSerializer

class PreferenceTypeAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = PreferenceTypeSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return PreferenceType.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return PreferenceTypeSerializer
        return PreferenceTypeSerializer

class PreferenceTypeUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = PreferenceTypeSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return PreferenceType.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return PreferenceTypeSerializer
        return PreferenceTypeSerializer

class ClusterAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = ClusterSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name','product__name')
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return Cluster.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ClusterSerializer
        return ClusterSerializer

class ClusterUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = ClusterSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return Cluster.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return ClusterSerializer
        return ClusterSerializer

class PlotTypeAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = PlotTypeSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return PlotType.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return PlotTypeSerializer
        return PlotTypeSerializer

class PlotTypeUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = PlotTypeSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return PlotType.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return PlotTypeSerializer
        return PlotTypeSerializer

class ProductAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = ProductSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name','key','business__name','business__key',)
    search_fields = ('name','key','business__name','business__key',)
    lookup_field = 'key'
    def get_queryset(self):
        return Product.objects.all()
    def post(self,request,format=None):
        parsed_data = request.data
        if 'clusters' in parsed_data:
            clusters = []
            in_clusters = parsed_data['clusters']
            for i in in_clusters:
                obj = Cluster()
                obj.name = i
                obj.save()
                clusters.append(str(obj.key))
            parsed_data['clusters'] = clusters
        if 'plots' in parsed_data:
            plots = []
            in_plots = parsed_data['plots']
            for i in in_plots:
                obj = PlotType()
                obj.name = i
                obj.save()
                plots.append(str(obj.key))
            parsed_data['plots'] = plots
        if 'business' not in parsed_data:
            parsed_data['business'] = None
        serializer = ProductWriteSerializer(data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            usrs = User.objects.all().values('username')
            for usr in usrs:
                user_pref_obj = UserPreferences()
                user_pref_obj.product = Product.objects.filter(key = str(serializer.instance.key))[0]
                user_pref_obj.pref_type = PreferenceType.objects.filter(name="UI")[0]
                user_pref_obj.account_user = AccountUser.objects.filter(account_user__username=usr['username'])[0]
                user_pref_obj.save()
                if len(serializer.instance.clusters.all())>0:
                    for cluster in serializer.instance.clusters.all():
                        pref_map_obj = PreferenceMapping()
                        pref_map_obj.save()
                        pref_map_obj.plots = serializer.instance.plots.all()
                        pref_map_obj.clusters = [cluster]
                        pref_map_obj.save()
                        user_pref_obj.pref_mappings.add(pref_map_obj)
                        user_pref_obj.save()
                else:
                    pref_map_obj = PreferenceMapping()
                    pref_map_obj.save()
                    pref_map_obj.plots = serializer.instance.plots.all()
                    pref_map_obj.clusters = serializer.instance.clusters.all()
                    pref_map_obj.save()
                    user_pref_obj.pref_mappings = [pref_map_obj]
                user_pref_obj.save()    
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)
            
class ProductUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = ProductSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name','key','business__name','business__key',)
    search_fields = ('name','key','business__name','business__key',)
    lookup_field = 'key'
    def get_queryset(self):
        return Product.objects.all()
    
    '''
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return ProductWriteSerializer
        return ProductSerializer
    '''
    
    def patch(self,request,key,format=None):
        parsed_data = request.data
        user_pref_objs = UserPreferences.objects.filter(product__key=str(key))
        if 'plots' in parsed_data and len(parsed_data['plots'])>0:
            updated_plots = []
            for plot in parsed_data['plots']:
                obj = PlotType.objects.filter(name=plot)
                if obj is not None and len(obj)>0:
                    updated_plots.append(str(obj[0].key))
                else:
                    obj = PlotType()
                    obj.name = plot
                    obj.save()
                    updated_plots.append(str(obj.key))
                    for usr_pref in user_pref_objs:
                        for pf in usr_pref.pref_mappings.all():
                            pf.plots.add(obj)
                            pf.save()
                            usr_pref.save()
                        usr_pref.save()
            parsed_data['plots'] = updated_plots
        if 'clusters' in parsed_data and len(parsed_data['clusters'])>0:
            updated_clusters = []
            for cluster in parsed_data['clusters']:
                obj = Cluster.objects.filter(name=cluster)
                if obj is not None and len(obj)>0:
                    updated_clusters.append(str(obj[0].key))
                else:
                    obj = Cluster()
                    obj.name = cluster
                    obj.save()
                    updated_clusters.append(str(obj.key))
                    for usr_pref in user_pref_objs:
                        pref_map = PreferenceMapping()
                        pref_map.save()
                        pref_map.clusters = [obj]
                        pref_map.plots = usr_pref.product.plots.all()
                        pref_map.save()
                        usr_pref.pref_mappings.add(pref_map)
                        usr_pref.save()
            parsed_data['clusters'] = updated_clusters
        product = Product.objects.get(key=key)
        if 'name' not in parsed_data:
            parsed_data['name'] = product.name
        serializer = ProductWriteSerializer(product,data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)

class PreferenceMappingAPIView(generics.ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    serializer_class = PreferenceMappingSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_fields = ('key','product__name','product__key',)
    #search_fields = ('key','product__name','product__key',)
    lookup_field = 'key'
    def get_queryset(self):
        return PreferenceMapping.objects.all()
    def post(self,request,format=None):
        parsed_data = request.data
        if 'plots' not in parsed_data or len(parsed_data['plots'])==0:
            if 'clusters' in parsed_data and len(parsed_data['clusters'])>0:
                return Response({"error":"clusters should be empty list if plots are empty!"},status = HTTP_400_BAD_REQUEST)
        serializer = PreferenceMappingWriteSerializer(data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)

class PreferenceMappingUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = PreferenceMappingSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    #filter_fields = ('key','product__name','product__key',)
    #search_fields = ('key','product__name','product__key',)
    lookup_field = 'key'
    def get_queryset(self):
        return PreferenceMapping.objects.all()
    '''
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return PreferenceMappingWriteSerializer
        return PreferenceMappingSerializer
    '''
    def patch(self,request,key,format=None):
        parsed_data = request.data
        if 'plots' not in parsed_data or len(parsed_data['plots'])==0:
            if 'clusters' in parsed_data and len(parsed_data['clusters'])>0:
                return Response({"error":"clusters should be empty list if plots are empty!"},status = HTTP_400_BAD_REQUEST)
        pref_map = PreferenceMapping.objects.get(key=key)
        serializer = PreferenceMappingWriteSerializer(pref_map,data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)

class UserPreferencesAPIView(generics.ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    serializer_class = UserPreferencesSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('key','product__name','product__key','pref_type__name',
                     'product__business__name', 'product__business__key')
    search_fields = ('key','product__name','product__key','pref_type__name',)
    lookup_field = 'key'
    def get_queryset(self):
        usr = self.request.user.username
        user_prefs = UserPreferences.objects.filter(account_user__account_user__username=usr)
        return user_prefs
    
    def post(self,request,format=None):
        usr = self.request.user.username
        parsed_data = request.data
        parsed_data['account_user'] = str(AccountUser.objects.filter(account_user__username=usr)[0].key)
        serializer = UserPreferencesWriteSerializer(data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=HTTP_201_CREATED)
    
class UserPreferencesUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = UserPreferencesSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('key','product__name','product__key',)
    search_fields = ('key','product__name','product__key',)
    lookup_field = 'key'
    def get_queryset(self):
        return UserPreferences.objects.all()
    def get_serializer_class(self):
        print self.request.data
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return UserPreferencesWriteSerializer
        return UserPreferencesSerializer

class CustomUserPreferencesAPIView(APIView):
    def get(self,request, format=None):
        authentication_classes = (TokenAuthentication,)
        #authentication_classes = (ExpiringTokenAuthentication,)
        business = request.query_params.get('business', "ALPHA")
        usr = self.request.user.username
        res = []
        res_obj = {}
        user_prefs = UserPreferences.objects.filter(account_user__account_user__username=usr)#.exclude(product__name="ENDPOINTS")
        #len(user_prefs)
        #return Response(len(user_prefs),status=HTTP_200_OK)
        prods = Product.objects.filter(business__name=business)#.exclude(name="ENDPOINTS")
        if len(user_prefs) <=0 :
            for p in prods:
                res_obj = {}
                prod_obj = {}
                prod_obj['name'] = p.name
                prod_obj['key'] = p.key
                #prod_obj['flag'] = True
                prod_obj['flag'] = False
                res_obj['product'] = prod_obj
                pref_maps = []
                plots = []
                for plot in p.plots.all():
                    plot_obj = {}
                    plot_obj['name'] = plot.name
                    plot_obj['key'] = plot.key
                    #plot_obj['flag'] = True
                    plot_obj['flag'] = False
                    plots.append(plot_obj)
                if len(p.clusters.all()) > 0 :
                    for c in p.clusters.all():
                        map_obj = {}
                        cluster_obj = {}
                        cluster_obj['name'] = c.name
                        cluster_obj['key'] = c.key
                        #cluster_obj['flag'] = True
                        cluster_obj['flag'] = False
                        map_obj['cluster'] = cluster_obj
                        map_obj['plots'] = plots
                        pref_maps.append(map_obj)
                else:
                    map_obj = {}
                    map_obj['plots'] = plots
                    map_obj['map_key'] = None
                    pref_maps.append(map_obj)
                res_obj['mappings'] = pref_maps
                res_obj['account_user'] = "default"
                res.append(res_obj)
        else:
            for p in prods:
                cnt = 0
                for pref in user_prefs:
                    if p.name == pref.product.name:
                        pref_map_objs = pref.pref_mappings.all()
                        res_obj = {}
                        pref_maps =[]
                        prod_obj = {}
                        prod_obj['name'] = p.name
                        prod_obj['key'] = p.key
                        prod_obj['flag'] = True
                        res_obj['product'] = prod_obj
                        non_plots = []
                        for plot in p.plots.all():
                            plot_obj = {}
                            plot_obj['name'] = plot.name
                            plot_obj['key'] = plot.key
                            plot_obj['flag'] = False
                            non_plots.append(plot_obj) 
                        if len(p.clusters.all())>0:
                            for cluster in p.clusters.all():
                                i = 0
                                flag = False
                                for i in range(len(pref_map_objs)):
                                    pref_plots = []
                                    for pp in pref_map_objs[i].plots.all():
                                        pref_plots.append(pp.name)
                                    map_obj = {}
                                    if cluster in pref_map_objs[i].clusters.all():
                                        flag=True
                                        plots = []
                                        cluster_obj = {}
                                        cluster_obj['name'] = cluster.name
                                        cluster_obj['key'] = cluster.key
                                        cluster_obj['flag'] = True
                                        map_obj['cluster'] = cluster_obj
                                        map_obj['map_key'] = pref_map_objs[i].key
                                        for np in non_plots:
                                            if np['name'] in pref_plots:
                                                ob = {}
                                                ob['flag'] = True
                                                ob['name'] = np['name']
                                                ob['key'] = np['key']
                                                plots.append(ob)
                                            else:
                                                plots.append(np)
                                        map_obj['plots'] = plots
                                        pref_maps.append(map_obj)
                                        break
                                if i+1 >= len(pref_map_objs) and not flag:
                                    map_obj = {}
                                    cluster_obj = {}
                                    cluster_obj['name'] = cluster.name
                                    cluster_obj['key'] = cluster.key
                                    cluster_obj['flag'] = False
                                    map_obj['cluster'] = cluster_obj
                                    map_obj['plots'] = non_plots
                                    map_obj['map_key'] = None
                                    pref_maps.append(map_obj)
                        else:
                            map_obj = {}
                            plots = []
                            i = 0
                            flag = False
                            for i in range(len(pref_map_objs)):
                                pref_plots = []
                                for pp in pref_map_objs[i].plots.all():
                                    pref_plots.append(pp.name)
                            map_obj['map_key'] = pref_map_objs[i].key
                            for np in non_plots:
                                if np['name'] in pref_plots:
                                    ob = {}
                                    ob['flag'] = True
                                    ob['name'] = np['name']
                                    ob['key'] = np['key']
                                    plots.append(ob)
                                else:
                                    plots.append(np)
                            map_obj['plots'] = plots
                            pref_maps.append(map_obj)
                        res_obj['mappings'] = pref_maps
                        res_obj['account_user'] = pref.account_user.account_user.username
                        res_obj['pref_key'] = pref.key
                        res.append(res_obj)
                    else:
                        cnt = cnt +1
                if cnt >= len(user_prefs):
                    res_obj = {}
                    prod_obj = {}
                    prod_obj['name'] = p.name
                    prod_obj['key'] = p.key
                    prod_obj['flag'] = False
                    res_obj['product'] = prod_obj
                    pref_maps = []
                    plots = []
                    for plot in p.plots.all():
                        plot_obj = {}
                        plot_obj['name'] = plot.name
                        plot_obj['key'] = plot.key
                        plot_obj['flag'] = False
                        plots.append(plot_obj)
                    if len(p.clusters.all()) > 0 :
                        for c in p.clusters.all():
                            map_obj = {}
                            cluster_obj = {}
                            cluster_obj['name'] = c.name
                            cluster_obj['key'] = c.key
                            cluster_obj['flag'] = False
                            map_obj['cluster'] = cluster_obj
                            map_obj['plots'] = plots
                            pref_maps.append(map_obj)
                    else:
                        map_obj = {}
                        map_obj['plots'] = plots
                        map_obj['map_key'] = None
                        pref_maps.append(map_obj)
                    res_obj['mappings'] = pref_maps
                    res_obj['account_user'] = "default"
                    res_obj['pref_key'] = None
                    res.append(res_obj)
        return Response(res,status=HTTP_200_OK)
