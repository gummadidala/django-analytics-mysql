'''
Created on 01-Dec-2017

@author: Koteswararao Gummadidala
'''
from __future__ import division
from jira.models import *
from random import randint
from datetime import datetime, timedelta
from operator import itemgetter
from django.db.models import Sum, Count, F
from django.db.models import Q

def re_arrange_dates(query_data, label, min_date, max_date):
    avail_dates = []
    for i in query_data:
        try:
            if i['date'] not in avail_dates:
                avail_dates.append(i['date'])
        except:
            return query_data
    ress = []
    for i in query_data:
        ress.append(i)

    while min_date <= max_date:
        if min_date not in avail_dates:
            obj = {}
            obj['date'] = min_date
            obj['call_count'] = 0
            obj["call_info"] = []
            ress.append(obj)
        min_date = min_date + timedelta(days=1)

    sorted_res = sorted(ress, key=lambda x: x['date'])
    for i in sorted_res:
        i["date"] = i["date"].strftime("%b %d %Y")
    dataset = {}
    dates = []
    count = []
    call_infos = []
    for r in sorted_res:
        dates.append(r['date'])
        count.append(r['call_count'])
        if "call_info" in r:
            call_infos.append(r['call_info'])

    dataset['labels'] = dates
    dataset['data'] = count
    dataset['label'] = label
    dataset['call_infos'] = call_infos
    
    return dataset

def get_graph_types(plot):
    graph_types = ["Bar","BarLine","HeatMap","HorizontalBar","Line", "Pie", "Stacked"]

    if plot in ["Defect Outflow"]:
            graph_types = ["Stacked"]
    elif plot in ["Defect Inflow"]:
        graph_types =["BarLine"]
    else:
        graph_types = ["Pie"]
            
    return graph_types

def get_ylabels(plot):
    yLabel = "Case Count"
    return yLabel

def get_aggregation_query(dt, plot):
    dt = "$"+dt
    if plot == "Defect Inflow":
        group_obj = {'_id':
                       {'date':{"month":{'$month':dt}
                                ,"day":{'$dayOfMonth':dt},
                                "year":{"$year":dt}
                                },
                        "origination":"$origination",
                        },
                       'count':{'$sum':'$count'}
                       }
    else:
        group_obj = {'_id':
                       {'date':{"month":{'$month':dt}
                                ,"day":{'$dayOfMonth':dt},
                                "year":{"$year":dt}
                                }
                        },
                       'count':{'$sum':'$count'}
                       }
    return group_obj

def Cumulative_count(ds, label):
    inc_data = []
    cumSum = 0
    for d in ds['data']:
        cumSum += d
        inc_data.append(cumSum)
    obj = {}
    obj['data'] = inc_data
    obj['label'] = label
    return obj

def get_jira_filter_fields(plot):
    obj = {}
    if plot == 'Status Distribution':
        obj['col'] = 'status'
        obj['date'] = 'created'
    elif plot == 'Priority Distribution':
        obj['col'] = 'priority'
        obj['date'] = 'created'
    elif plot == 'Severity Distribution':
        obj['col'] = 'severity'
        obj['date'] = 'created'
    elif plot == 'Origination Distribution':
        obj['col'] = 'origination'
        obj['date'] = 'created'
    elif plot == 'Issue Type':
        obj['col'] = 'issuetype'
        obj['date'] = 'created'
    elif plot == 'Component Distribution':
        obj['col'] = 'components'
        obj['date'] = 'created'
    elif plot == 'Label Distribution':
        obj['col'] = 'labels'
        obj['date'] = 'created'
    elif plot == 'Version Distribution':
        obj['col'] = 'versions'
        obj['date'] = 'created'
    elif plot == 'Defect Inflow':
        obj['col'] = 'status'
        obj['date'] = 'created'
    elif plot == 'Defect Outflow':
        obj['col'] = 'status'
        obj['date'] = 'resolved'
    return obj

def get_sum_of_sub_data(datasets):
    new_datasets = []
    new_labels = []
    unique_labels = []

    for ds in datasets:
        if ds['label'] not in unique_labels:
            unique_labels.append(ds['label'])

    for ul in unique_labels:
        for ds in datasets:
            if ul == ds['label']:
                if ul not in new_labels:
                    obj = {}
                    obj['label'] = ul
                    obj['data'] = ds['data']
                    obj['labels'] = ds['labels']
                    obj['versions'] = ds['versions']
                    new_datasets.append(obj)
                    new_labels.append(ul)
                else:
                    for nds in new_datasets:
                        if ul == nds['label']:
                            for j in range(len(ds["data"]) - 1):
                                try:
                                    nds["data"][j] += ds["data"][j]
                                except:
                                    return new_datasets

    return new_datasets

def get_jira_pie_data(dataset,cluster,start_date,end_date,typ,col,version):
    
    if version is not None:
        cases_query = JiraData.objects.filter(**{col:typ}).filter(versions__icontains=version,project__in = cluster, created__gte = start_date, created__lte = end_date).values("issueid")

    else:
        cases_query = JiraData.objects.filter(**{col:typ}).filter(project__in = cluster,created__gte = start_date, created__lte = end_date).values("issueid")
    
    if cases_query is not None and len(cases_query)>0:
        cases = [a['issueid'] for a in cases_query]
        dataset["cases"] = typ+': '+', '.join(cases)
    dataset['data'] = [sum(dataset['data'])]
    return dataset

def get_jira_data(plot,cluster,start_date,end_date,mavg,version):
    res = {}
    datasets = []
    list_query_data = []
    types = []
    graph_types = get_graph_types("JIRA", plot)
    filter = get_jira_filter_fields(plot)
    clusters = []
    if cluster:
        clusters = cluster.split(',')
    d = filter['date']
    f = "date(" + d + ")"
    
    if plot == "Defect Inflow":
        obj = {}
        if version is None:
            query_res = JiraData.objects.filter(origination__in = ["Alpha", "EFT"], project__in = clusters,created__gte = start_date,created__lte=end_date).extra({'date':f}).annotate(date=F(d)).values("date").annotate(call_count=Sum("count"))
        else:
            query_res = JiraData.objects.filter(origination__in = ["Alpha", "EFT"], project__in = clusters,versions__icontains=version,created__gte=start_date, created__lte=end_date).extra({'date':f}).annotate(date=F(d)).values("date").annotate(call_count=Sum("count"))
        obj['type'] = "Cases Created Count"
        obj['query_data'] = query_res
        list_query_data.append(obj)


    elif plot == "Defect Outflow":
        if version is not None:
            query_res = JiraData.objects.filter(project__in = clusters,versions__icontains=version,resolved__gte=start_date, resolved__lte=end_date).extra({'date':f}).annotate(date=F(d)).values("date").annotate(call_count=Sum("count"))
        else:
            query_res = JiraData.objects.filter(project__in = clusters,resolved__gte = start_date,resolved__lte=end_date).extra({'date':f}).annotate(date=F(d)).values("date").annotate(call_count=Sum("count"))
        obj = {}
        obj['type'] = "Cases Resolved Count"
        obj['query_data'] = query_res
        list_query_data.append(obj)

    else:
        if version is not None:
            types_query = JiraData.objects.filter(versions__icontains=version,project__in =clusters,created__gte=start_date, created__lte=end_date).values(filter['col'])
        else:
            types_query = JiraData.objects.filter(project__in = clusters,created__gte=start_date, created__lte=end_date).values(filter['col'])
        for q in types_query:
            if q[filter['col']] and q[filter['col']] not in types and q[filter['col']] not in ["?"]:
                types.append(q[filter['col']])
                
        for typ in types:
            if version is not None:
                query_res = JiraData.objects.filter(**{filter['col'] : typ}).filter(project__in = clusters,versions__icontains=version,created__gte=start_date, created__lte=end_date).extra({'date':f}).annotate(date=F(d)).values("date").annotate(call_count=Sum("count"))
            else:
                query_res = JiraData.objects.filter(**{filter['col'] : typ}).filter(project__in = clusters,created__gte=start_date, created__lte=end_date).extra({'date':f}).annotate(date=F(d)).values("date").annotate(call_count=Sum("count"))
            obj = {}
            obj['type'] = typ
            obj['query_data'] = query_res
            list_query_data.append(obj)
                                                                      
    for q_data in list_query_data: 
        end_date = end_date +timedelta(days=-1)
        res_data = re_arrange_dates(q_data['query_data'], q_data['type'], start_date, end_date,"JIRA", cluster, plot)
        
        if "Pie" in graph_types:
            end_date = end_date +timedelta(days=1)
            res_data = get_jira_pie_data(res_data,clusters, start_date, end_date, q_data['type'], filter['col'],version)
            #return res_data
        datasets.append(res_data)

    if len(datasets) > 0:
        if plot == "Defect Inflow":
            datasets.append(Cumulative_count(datasets[0],"Total Count"))
            ds = []
            labels = ["alpha","eft"]
            for l in labels:
                if version:
                    label_data = JiraData.objects.filter(labels__icontains=l,project__in=clusters,versions__icontains=version,created__gte=start_date, created__lte=end_date).extra({'date':f}).annotate(date=F(d)).values("date").annotate(call_count=Sum("count"))#.order_by("date")
                else:
                    label_data = JiraData.objects.filter(labels__icontains=l,project__in=clusters,created__gte=start_date, created__lte=end_date).extra({'date':f}).annotate(date=F(d)).values("date").annotate(call_count=Sum("count"))#.order_by("date")
                label_data = re_arrange_dates(label_data, "Label count", start_date, end_date,"JIRA", cluster, plot)
                ds.append(label_data)
            label_data = get_sum_of_sub_data(ds)
            
            if sum(label_data[0]['data'])>0:
                datasets.append(Cumulative_count(label_data[0],"Seen by Trials"))
        res['dataset']= datasets
        res['labels'] = datasets[0]['labels']
        res['graphTypes'] = get_graph_types("JIRA", plot)
        res['yLabel'] = get_ylabels("JIRA", plot)
        if graph_types[0] == "Pie":
            res['labels'] = types
    if not res:
        return None
    else:
        if plot == "Label Distribution":
            new_labels=[]
            new_datasets = []
            new_data = []
            new_cases = []
            for label in res['labels']:
                labels = label.split(', ')
                for l in labels:
                    if l not in new_labels:
                        new_labels.append(l)
            for new_l in new_labels:
                new_ds = {}
                cnt = 0
                case_str = ""
                #new_ds['label'] = new_l
                for ds in res['dataset']:
                    if new_l in ds['label']:
                        case_str = case_str +ds['cases'].split(': ')[1]+', '
                        cnt += ds['data'][0]
                #new_ds['data'] = [cnt]
                new_data.append(cnt)
                case_str  = case_str[:-2]
                new_cases.append(case_str)
                #new_datasets.append(new_ds)
            res['labels'] = new_labels
            res['dataset'] = [{'data':new_data, 'label':"Label",'cases':new_cases}]
            res['graphTypes'] = ["HorizontalBar"]

            
        return res