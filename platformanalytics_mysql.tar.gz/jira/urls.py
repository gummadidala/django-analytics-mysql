'''
Created on 15-Sept-2017

@author: Koteswararao Gummadidala
'''
from django.conf.urls import url
from jira import views
urlpatterns = [
                url(r'^api/plotjira/', views.JIRAPlotAPIView.as_view()),
                url(r'^api/jiraversions/', views.JIRAVersionsAPIView.as_view()),
            ]