'''
Created on 15-Sept-2017

@author: Koteswararao Gummadidala
'''
from django.db import models

class JiraData(models.Model):
    issueid = models.CharField(default="", null=True,blank=True, max_length=255)
    issuetype = models.CharField(default="", null=True,blank=True, max_length=255)
    project = models.CharField(default="", null=True,blank=True, max_length=255)
    components = models.CharField(default="", null=True,blank=True, max_length=255)
    origination = models.CharField(default="", null=True,blank=True, max_length=255)
    cap = models.CharField(default="", null=True,blank=True, max_length=255)
    priority = models.CharField(default="", null=True,blank=True, max_length=255)
    severity = models.CharField(default="", null=True,blank=True, max_length=255)
    status = models.CharField(default="", null=True,blank=True, max_length=255)
    created = models.DateTimeField(null=True,blank=True)
    updated = models.DateTimeField(null=True,blank=True)
    assignee = models.CharField(default="", null=True,blank=True, max_length=255)
    creator = models.CharField(default="", null=True,blank=True, max_length=255)
    reporter = models.CharField(default="", null=True,blank=True, max_length=255)
    fixVersions = models.CharField(default="", null=True,blank=True, max_length=255)
    versions = models.CharField(default="", null=True,blank=True, max_length=255)
    labels = models.CharField(default="", null=True,blank=True, max_length=255)
    count = models.IntegerField()
    resolved = models.DateTimeField(null=True,blank=True)