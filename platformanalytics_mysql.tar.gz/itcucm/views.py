'''
Created on 15-Sept-2017

@author: Koteswararao Gummadidala
'''
from rest_framework import parsers, renderers
from rest_framework import generics
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST, HTTP_200_OK
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
import django_filters
from rest_framework import filters
from itcucm.models import *
from datetime import datetime, timedelta
from dateutil.parser import parse
from itcucm.serializers import *
from itcucm.utils import get_cucm_data
from cdets.models import *
from jira.models import *

class CUCMVersionsAPIView(APIView):
    def get(self,request, format=None):
        authentication_classes = (TokenAuthentication,)
        #authentication_classes = (ExpiringTokenAuthentication,)
        username = self.request.user.username
        cluster = request.query_params.get('cluster', None)
        product = request.query_params.get('product', None)
        plot=request.query_params.get('plot', None)
        end_date = datetime.now().date().strftime("%Y-%m-%d")
        start_date =(datetime.now().date() + timedelta(days=-90)).strftime("%Y-%m-%d")
        if cluster == "ALL":
            cluster = None
        avail_versions = []
        if plot is None:
            return Response({"error: Please enter the plot name!"},status=HTTP_400_BAD_REQUEST)
        if "CDETS" in plot:
            cdets_versions = CdetsData.objects.filter(Product="ciscocm", Submitted_date__gte=start_date,
                                                      Submitted_date__lte=end_date,
                                                      Attribute__in=["EFT", "Alpha"]).values("Version")
            if cdets_versions is not None and len(cdets_versions) > 0:
                for cv in cdets_versions:
                    if cv['Version'] not in avail_versions:
                        avail_versions.append(cv['Version'])

        elif "JIRA" in plot:
            jira_versions = JiraData.objects.filter(project="CUCM", created__gte=start_date, created__lte=end_date,
                                                    origination__in=["EFT", "Alpha"]).values("versions")
            for jv in jira_versions:
                vers = jv['versions'].split(', ')
                for v in vers:
                    if v not in avail_versions:
                        avail_versions.append(v)
        else:
            if cluster is not None:
                clstrs = cluster.split(",")
            else:
                clstrs = []
                cluster_res = Cucmversion.objects.values("cluster")
                for cr in cluster_res:
                    if cr['cluster'] not in clstrs:
                        clstrs.append(cr['cluster'])
            #print clstrs
            for cluster in clstrs:
                cucm_versions = Cucmversion.objects.filter(cluster=cluster,changeDate__gte=start_date, changeDate__lte=end_date)

                if cucm_versions is None or len(cucm_versions)==0:
                    cucm_versions = Cucmversion.objects.filter(cluster=cluster).order_by("-changeDate")
                    if cucm_versions is not None and len(cucm_versions) > 0:
                        cucm_versions = [cucm_versions[0]]

                else:
                    res_arr = []
                    for i in cucm_versions:
                        res_arr.append(i)
                    vers = []
                    res_arr.append(cucm_versions[0])
                    for ver in cucm_versions:
                        vers.append(ver.version)

                    new_cucm_versions = Cucmversion.objects.filter(cluster=cluster).exclude(version__in=vers).order_by("-changeDate")
                    if new_cucm_versions is not None and len(new_cucm_versions)>0:
                        res_arr.append(new_cucm_versions[0])
                        cucm_versions = res_arr

                if cucm_versions is not None and len(cucm_versions)>0:
                    for cv in cucm_versions:
                        if cv.version not in avail_versions and cv.version not in ["",None]:
                            avail_versions.append(cv.version)
                                
        if 'no version' in avail_versions:
            avail_versions.remove('no version')
        return Response(avail_versions, status = HTTP_200_OK)

def get_plot_tooltips(plots):
    res = []
    for plot in plots:
        obj = {}
        obj['key']= plot
        if plot == "Call Status":
            obj['tooltip'] = "Plots Successful calls vs Failed calls"
        elif plot == "Secure~Non-secure Calls":
            obj['tooltip'] = "Stacked bar chart of Authenticated, Secured and Non-Secured calls"
        elif plot == "WebEx Calls":
            obj['tooltip'] = "Plots Webex calls"
        elif plot == "Hybrid Calls":
            obj['tooltip'] = "Plots Spark Hybrid calls"
        elif plot == "Audio~Video Calls":
            obj['tooltip'] = "Stacked bar chart of Audio, Video calls"
        elif plot == "Codecs Used":
            obj['tooltip'] = "Plots various audio and video codecs used in calls"
        elif plot == "Endpoints Participation":
            obj['tooltip'] = "Plots number of endpoints participating in calls per day"
        elif plot == "Call Features":
            obj['tooltip'] = "Heatmap of call features used across calls"
        elif plot == "Call Failure Causes":
            obj['tooltip'] = "Heatmap indicating various call failure reasons"
        elif plot == "IPv4~IPv6 Stat":
            obj['tooltip'] = "Stacked bar chart of IPv4 and IPv6 calls"
        elif plot == "Talktime":
            obj['tooltip'] = "Bar Line plot showing talktime per day"
        elif plot == "Top Active Users":
            obj['tooltip'] = "Top Active Users"
        elif plot == "Least Active Users":
            obj['tooltip'] = "Least Active Users"
        elif plot == "Audio":
            obj['tooltip'] = "Secure and Non-secure"

        res.append(obj)
    return res

class EndpointsAPIView(APIView):
    def get(self,request, format=None):
        authentication_classes = (TokenAuthentication,)
        #authentication_classes = (ExpiringTokenAuthentication,)
        #username = self.request.user.username
        prods = Product.objects.filter(name="CUCM")
        res = {}
        clusters = []
        plots = []
        end_points = []
        if prods is not None and len(prods)>0:
            cluster_objs = prods[0].clusters.all()
            if cluster_objs is not None and len(cluster_objs)>0:
                for cluster in cluster_objs:
                    clusters.append(cluster.name) 
                if "ALL" in clusters:
                    clusters.remove("ALL")
            res['clusters'] = clusters
            plot_objs = prods[0].plots.all()
            if plot_objs is not None and len(plot_objs)>0:
                for plot in plot_objs:
                    if "JIRA" not in plot.name and "CDETS" not in plot.name:
                        plots.append(plot.name) 
            plots.append('Top Active Users')
            plots.append('Least Active Users')
            plots.remove('Endpoints Participation')
            plots.remove('Users')
            res['plots'] = get_plot_tooltips(plots)
        end_date = datetime.now().date().strftime("%Y-%m-%d")
        start_date =(datetime.now().date() + timedelta(days=-90)).strftime("%Y-%m-%d")
        endpoints = []
        endpoint_objs = CucmData.objects.filter(date__gte=start_date, date__lte=end_date).values('origModel','destModel')
        if endpoint_objs is not None and len(endpoint_objs)>0:
            for ep in endpoint_objs:
                if ep['origModel'] not in endpoints:
                    endpoints.append(ep['origModel'])
                if ep['destModel'] not in endpoints:
                    endpoints.append(ep['destModel'])
        res['endpoints'] = endpoints
        return Response(res, status = HTTP_200_OK)

class CUCMPlotAPIView(APIView):
    def get(self,request, format=None):
        authentication_classes = (TokenAuthentication,)
        #authentication_classes = (ExpiringTokenAuthentication,)
        cluster = request.query_params.get('cluster', None)
        plot = request.query_params.get('plot', None)
        version = request.query_params.get('version', None)
        start_date = parse(request.query_params.get('start_date',"2017-08-01")).date()
        end_date = parse(request.query_params.get('end_date',datetime.now().date().strftime("%Y-%m-%d"))).date()+timedelta(days=1)
        model = request.query_params.get('model', None)
        description = request.query_params.get('description', None)
        mavg = request.query_params.get('movingAvg', "False")
        num_users = int(request.query_params.get('num_users', 20))
        
        if cluster == "ALL":
            cluster = None
        if cluster and "CUCM" in cluster and len(cluster) > len("CUCM"):
            arr = cluster.split(" ")
            version = arr[1]
        if description is not None:
            if len(description) == 0:
                description = None
        plotendpoints = None
        if "endpoints" in str(request.path):
            plotendpoints = True
        if start_date is None or end_date is None or plot is None:
            return Response({"error":"please provide all mandatory fields like start date, end date and plot!"},status=HTTP_400_BAD_REQUEST)
        else:
            if "JIRA" in plot:
                res = get_jira_data(plot.split('_')[1], "CUCM,Cisco Unity Express,IM&P,Unity Connection", start_date, end_date, mavg, version)
            elif 'CDETS' in plot:
                res = get_cdets_data(plot.split('_')[1], "ciscocm", start_date, end_date, mavg, version)
            else:
                res = get_cucm_data(plot, cluster, start_date, end_date, version, model, description, mavg, num_users,plotendpoints)
            if not res:
                return Response({"error":"Data not found"},status=HTTP_400_BAD_REQUEST)
            else:
                return Response(res,status=HTTP_200_OK)
            
class CucmCategoryAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = CucmCategorySerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('type',)
    search_fields = ('type',)
    lookup_field = 'key'
    def get_queryset(self):
        return CucmCategory.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return CucmCategorySerializer
        return CucmCategorySerializer

class CucmCategoryUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = CucmCategorySerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('type',)
    search_fields = ('type',)
    lookup_field = 'key'
    def get_queryset(self):
        return CucmCategory.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return CucmCategorySerializer
        return CucmCategorySerializer
    
class CucmGeneralAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = CucmGeneralSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('type',)
    search_fields = ('type',)
    lookup_field = 'key'
    def get_queryset(self):
        return CucmGeneral.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return CucmGeneralSerializer
        return CucmGeneralSerializer

class CucmGeneralUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = CucmGeneralSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('type',)
    search_fields = ('type',)
    lookup_field = 'key'
    def get_queryset(self):
        return CucmGeneral.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return CucmGeneralSerializer
        return CucmGeneralSerializer

