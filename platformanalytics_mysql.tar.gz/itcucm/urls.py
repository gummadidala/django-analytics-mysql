'''
Created on 15-Sept-2017

@author: Koteswararao Gummadidala
'''
from django.conf.urls import url
from alphacucm import views
urlpatterns = [
                url(r'^api/plotcucm/', views.CUCMPlotAPIView.as_view()),
                url(r'^api/plotendpoints/', views.CUCMPlotAPIView.as_view()),
                url(r'^api/plotrelease/', views.CUCMPlotAPIView.as_view()),
                url(r'^api/cucmversions/', views.CUCMVersionsAPIView.as_view()),
                url(r'^api/endpoints/', views.EndpointsAPIView.as_view()),
                url(r'^api/cucmcategory/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$', 
                    views.CucmCategoryUpdateAPIView.as_view()),
                url(r'^api/cucmcategory/', views.CucmCategoryAPIView.as_view()),
                url(r'^api/cucmgeneral/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                     views.CucmGeneralUpdateAPIView.as_view()),
                url(r'^api/cucmgeneral/', views.CucmGeneralAPIView.as_view()),
                ]