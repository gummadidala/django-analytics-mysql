'''
Created on 01-Dec-2017

@author: Koteswararao Gummadidala
'''

from __future__ import division
from itcucm.models import *
from random import randint
from datetime import datetime, timedelta
from operator import itemgetter
from django.db.models import Sum, Count, F
from django.db.models import Q

def get_additional_cucm_data(query_data):
    new_query_data = []
    unique_dates = []
    for qd in query_data:
        if qd['date'] not in unique_dates:
            unique_dates.append(qd['date'])
            obj = {}
            obj['date'] = qd['date']
            obj['call_count'] = qd['call_count']
            obj['call_info'] = []
            call_info_obj = {}
            call_info_obj['calling_number'] = qd["callingPartyNumber"]
            call_info_obj['called_number'] = qd["finalCalledPartyNumber"]
            call_info_obj['call_id'] = qd['globalCallID_callId']
            call_info_obj['time_stamp'] = qd['dateTimeOrigination']

            obj['call_info'].append(call_info_obj)

            new_query_data.append(obj)
        else:
            for nqd in new_query_data:
                if nqd['date'] == qd['date']:
                    nqd['call_count'] += qd['call_count']
                    call_info_obj = {}
                    call_info_obj['calling_number'] = qd["callingPartyNumber"]
                    call_info_obj['called_number'] = qd["finalCalledPartyNumber"]
                    call_info_obj['call_id'] = qd['globalCallID_callId']
                    call_info_obj['time_stamp'] = qd['dateTimeOrigination']
                    nqd['call_info'].append(call_info_obj)

    return new_query_data

def re_arrange_dates(query_data, label, min_date, max_date, plot):
    if plot == "Call Failure Causes":
        query_data = get_additional_cucm_data(query_data)
    avail_dates = []
    for i in query_data:
        try:
            if i['date'] not in avail_dates:
                avail_dates.append(i['date'])
        except:
            return query_data
    ress = []
    for i in query_data:
        ress.append(i)

    while min_date <= max_date:
        if min_date not in avail_dates:
            obj = {}
            obj['date'] = min_date
            obj['call_count'] = 0
            obj["call_info"] = []
            ress.append(obj)
        min_date = min_date + timedelta(days=1)

    sorted_res = sorted(ress, key=lambda x: x['date'])
    for i in sorted_res:
        i["date"] = i["date"].strftime("%b %d %Y")
    dataset = {}
    dates = []
    count = []
    call_infos = []
    for r in sorted_res:
        dates.append(r['date'])
        count.append(r['call_count'])
        if "call_info" in r:
            call_infos.append(r['call_info'])

    dataset['labels'] = dates
    dataset['data'] = count
    dataset['label'] = label
    dataset['call_infos'] = call_infos
    
    return dataset

def Calculate_Moving_Average(data):
    cumsum, moving_aves = [0],[] 
    n = 7
    for i,x in enumerate(data,1):
        cumsum.append(cumsum[i-1] + x)
        if i>=n:
            moving_ave = (cumsum[i] - cumsum[i-n])/n
            moving_aves.append(round(moving_ave,2))
        else:
            moving_aves.append(0)
    obj = {}
    obj['data'] = moving_aves
    obj['label'] = 'MovingAVG'
    return obj          

def get_graph_types(plot):
    graph_types = ["Bar","BarLine","HeatMap","HorizontalBar","Line", "Pie", "Stacked"]
    
    if plot in ["Call Status", "Hybrid Calls", "IPv4~IPv6 Stat", "Codecs Used", "WebEx Calls",
                "Secure~Non-secure Calls", "Audio~Video Calls", "Secure Audio~Video Calls", "Call Scenarios","Audio (Secured~Non-Secured)", "Video (Secured~Non-Secured)"]:
        graph_types = ["Stacked", "Line", "Bar","BarLine"]
    elif plot in ["Talktime"] :
        graph_types = ["BarLine","Bar","Line","Stacked"]
    elif  plot == "Call Success~Rate":
        graph_types=["Line","Bar","BarLine","Stacked"]
    elif plot == "Endpoints Participation" or plot == "Call Failure Causes" or plot == "Call Features":
        graph_types = ["Heatmap"]
    elif plot == "Users":
        graph_types = ["PieDoughnut"]
    elif plot == "Top Active Users" or plot =="Least Active Users":
        graph_types = ["HorizontalBar"]
    elif plot == "Webex Meeting" or plot =="Webex Conference":
        graph_types=["BarLine"]

    return graph_types

def get_ylabels(plot):
    yLabel = "Call Count"
    if plot == "Call Status" or plot == "Hybrid Calls" or plot == "IPv4~IPv6 Stat" or plot == "Codecs Used"\
                or plot =="WebEx Calls" or plot == "Secure~Non-secure Calls" or plot == "Audio~Video Calls" or plot =="Audio (Secured~Non-Secured)" or plot =="Video (Secured~Non-Secured)" or plot == "Call Success~Rate" or plot =="WebexMetting" or plot=="Webex Conference" :
            yLabel = "Call Count"
    elif plot == "Talktime" :
        yLabel = "Duration in hours"
    elif plot == "Endpoints Participation":
        yLabel = "Endpoints"
    elif plot == "Call Failure Causes":
        yLabel = "Causes"
    elif plot == "Call Features":
        yLabel = "Call Features"
    elif plot == "Users":
        yLabel = "Call Count"
    elif plot == "Top Active Users" or plot =="Least Active Users":
        yLabel = "Username"
            
    return yLabel

def get_sum_of_sub_data(datasets):
    new_datasets = []
    new_labels = []
    unique_labels = []

    for ds in datasets:
        if ds['label'] not in unique_labels:
            unique_labels.append(ds['label'])

    for ul in unique_labels:
        for ds in datasets:
            if ul == ds['label']:
                if ul not in new_labels:
                    obj = {}
                    obj['label'] = ul
                    obj['data'] = ds['data']
                    obj['labels'] = ds['labels']
                    obj['versions'] = ds['versions']
                    new_datasets.append(obj)
                    new_labels.append(ul)
                else:
                    for nds in new_datasets:
                        if ul == nds['label']:
                            for j in range(len(ds["data"]) - 1):
                                try:
                                    nds["data"][j] += ds["data"][j]
                                except:
                                    return new_datasets

    return new_datasets

def extract_model_series(datasets):
    datasets = get_sum_of_sub_data(datasets)
    new_datasets = []
    new_labels = []
    endpoints = ["Cisco 78", "Cisco 88", "Cisco 79", "Cisco 89", "Cisco 99", "Cisco ATA 1"]
    series = ["7800 Series", "8800 Series", "7900 Series", "8900 Series", "9900 Series", "Cisco ATA"]
    n = len(endpoints)
    for i in range(n):
        for ds in datasets:
            if endpoints[i] in ds['label']:
                if series[i] in new_labels:
                    for nds in new_datasets:
                        if series[i] == nds["label"]:
                            for j in range(len(ds["data"])-1):
                                nds["data"][j] += ds["data"][j] 
                else:
                    obj = {}
                    obj['label'] = series[i]
                    obj["data"] = ds["data"]
                    obj["labels"] = ds["labels"]
                    obj['versions'] = ds['versions']
                    new_datasets.append(obj)
                    new_labels.append(series[i])
            else:
                if i == n-1:
                    cnt = 0
                    for k in endpoints:
                        if k in ds["label"]:
                            break
                        else:
                            cnt +=1
                    if cnt >= n:
                        new_datasets.append(ds)                                                                                                     
    return new_datasets

def filter_cucmversions(cucmversions):
    vers = []
    return_res = []
    for cv in cucmversions:
        if cv['version'] not in vers:
            vers.append(cv['version'])
            return_res.append(cv)
        else:
            for v in return_res:
                if cv['version'] == v['version']:
                    if cv['date'] < v['date']:
                        v['date'] = cv['date']
    return return_res

def get_cucm_filters(plot):
    obj = {}
    if plot == 'Call Status':
        obj['type_col'] = ["fmtStatus"]
        obj['count_col'] = "count"

    elif plot == "Codecs Used":
        obj['type_col'] = ["fmtCodec"]
        obj['count_col'] = "count"

    elif plot == "IPv4~IPv6 Stat":
        obj['type_col'] = ["callType"]
        obj['count_col'] = "count"

    elif plot == "Secure~Non-secure Calls":
        obj['type_col'] = ["fmtSecureStat"]
        obj['count_col'] = "count"

    elif plot in ["Audio~Video Calls", "Secure Audio~Video Calls"]:
        obj['type_col'] = ["fmtAVType"]
        obj['count_col'] = "count"

    elif plot == "Talktime":
        obj['type_col'] = ["talktime"]
        obj['count_col'] = "talktime_duration"

    elif plot == "WebEx Calls":
        obj['type_col'] = ["fmtCloudType"]
        obj['count_col'] = "count"

    elif plot == "Hybrid Calls":
        obj['type_col'] = ["fmtStatus"]
        obj['count_col'] = "count"

    elif plot == "Call Failure Causes":
        obj['type_col'] = ["fmtCause"]
        obj['count_col'] = "count"

    elif plot == "Call Features":
        obj['type_col'] = ["fmtRReason"]
        obj['count_col'] = "count"

    elif plot == "Endpoints Participation":
        obj['type_col'] = ["origModel", "destModel"]
        obj['count_col'] = "count"

    elif plot in ["Top Active Users", "Least Active Users"]:
        obj['type_col'] = ["origUsername", "destUsername"]
        obj['count_col'] = "count"

    elif plot in ["Call Scenarios"]:
        obj['type_col'] = ["call_scenarios"]
        obj['count_col'] = "count"

    elif plot == "Audio (Secured~Non-Secured)":
        obj['type_col'] = ["fmtSecureStat"]
        obj['count_col'] = "count"

    elif plot == "Video (Secured~Non-Secured)":
        obj['type_col'] = ["fmtSecureStat"]
        obj['count_col'] = "count"

    elif plot == "Call Success~Rate":
        obj['type_col'] = ["fmtStatus"]
        obj['count_col'] = "count"

    elif plot =="Webex Meeting":
        obj['type_col'] = ["call_scenarios"]
        obj['count_col'] = "count"

    elif plot == "Webex Conference":
        obj['type_col'] = ["call_scenarios"]
        obj['count_col'] = "count"

    return obj

def get_total_percentages(res):

    return_res = []
    listarray = []
    successrate =[]

    for ds in res['dataset']:
        listarray.append(ds['data'])
    result = [sum(x) for x in zip(*listarray)]

    for ds in res['dataset']:
        for idx, val in enumerate(ds['labels']):
            # if(ds['label']=="Success"):
                try:
                    if (result[idx] == 0):
                        successrate.append(0)
                    else:
                        successrate.append(round(ds['data'][idx] / result[idx],5))
                except IndexError:
                    print "success rate"

        obj ={}
        obj['data']= successrate
        obj['label']= "Call Success Rate"
        return_res.append(obj)
        return  return_res


    return res

def get_users_data(clusters, plot):
    types = []
    today  = datetime.now().date().strftime('%Y-%m-%d')
    if len(clusters)>0:
        usr_data = CucmUserInfo.objects.filter(date=datetime.now().date(), cluster__in=clusters).values("type").annotate(call_count=Sum("count"))
    else:
        usr_data = CucmUserInfo.objects.filter(date=datetime.now().date()).values("type").annotate(call_count=Sum("count"))
    for d in usr_data:
        if d['type'].split(',')[0] not in types:
            types.append(d['type'].split(',')[0])
    res_obj = {}
    res = []
    for tp in types:
        Mobj= {}
        Mobj['nodeData'] = {}
        Mobj['subData'] = []
        Mobj['nodeData']['age'] = tp
        Mobj['nodeData']['population'] = 0
        for d in usr_data:
            if tp in d['type']:
                obj = {}
                obj['nodeData'] = {}
                obj['nodeData']['age'] =  d['type'].split(',')[1] +'-'+ str(int(d['call_count']))
                obj['nodeData']['population'] = d['call_count']
                Mobj['nodeData']['population'] += d['call_count']
                Mobj['subData'].append(obj)
        Mobj['nodeData']['age'] = tp +'-'+ str(Mobj['nodeData']['population'])
        res.append(Mobj)
    res_obj['subData'] = res
    res_obj['graphTypes'] = get_graph_types(plot)
    res_obj['yLabel'] = get_ylabels(plot)
    return res_obj

def get_activeUsers_data(datasets, plot, num_users):
    new_sum_res = []
    new_sum_labels = []
    for nr in datasets:
        unames = ["origUsername", "destUsername"]
        for un in unames:
            if un in nr:
                if nr[un] not in new_sum_labels:
                    obj = {}
                    obj['username'] = nr[un]
                    obj['call_count'] = nr['call_count']
                    new_sum_labels.append(nr[un])
                    new_sum_res.append(obj)
                else:
                    for nsr in new_sum_res:
                        if nr[un] == nsr['username']:
                            nsr['call_count'] += nr['call_count']
    if plot == "Top Active Users":
        new_sum_res = sorted(new_sum_res, key=itemgetter("call_count"), reverse=True)

    else:
        new_sum_res = sorted(new_sum_res, key=itemgetter("call_count"))
    new_sum_res = new_sum_res[:num_users]

    labels = []
    data = []
    for i in new_sum_res:
        labels.append(i['username'])
        data.append(i['call_count'])
    dataset = {}
    dataset['data'] = data
    dataset['label'] = "Call Count"

    res_obj = {}
    res_obj['dataset'] = []
    res_obj['dataset'].append(dataset)
    res_obj['labels'] = labels
    res_obj['graphTypes'] = get_graph_types(plot)
    res_obj['yLabel'] = get_ylabels(plot)
    return res_obj

def get_hybrid_data(plot, cluster, start_date, end_date, version, model, description, mavg, num_users,
                  plotendpoints=None):
    filters = get_cucm_filters(plot)
    val = "date",
    clusters = []
    if cluster is not None:
        clusters = cluster.split(',')
        val = "date", "version",
    if plotendpoints:
        val = "date",
    models = []
    if model is not None:
        models = model.split(',')

    if plot == "Hybrid Calls":
        call_scenarios = ["HybridCall"]

    elif plot == "Webex Conference":
        call_scenarios = ["Webex Conference Room Endpoint"]

    elif plot == "Webex Meeting":
        call_scenarios = ["WebexMeeting"]

    if version is not None:
        if "CUCM" in cluster and len(cluster) > len("CUCM"):
            cluster = None
            clusters=[]
            results_set = Cucmversion.objects.filter(version__icontains=version).values("changeDate","version","cluster").order_by("changeDate")
            cluster_res = Cucmversion.objects.filter(version__icontains=version).values("cluster")
            new_clusters = []
            if cluster_res is not None and len(cluster_res)>0:
                for cr in cluster_res:
                    new_clusters.append(cr['cluster'])
                clusters = new_clusters
        else:
            results_set = Cucmversion.objects.filter(cluster__in=clusters,version__icontains=version).values("changeDate","version").order_by("changeDate")
        if results_set is not None and len(results_set)>0:
            rs_len = len(results_set)
            start_date = datetime.now().date()
            for i in range(len(results_set)):
                if version in results_set[i]['version']:
                    curr_start_date = results_set[i]['changeDate']
                    if curr_start_date < start_date:
                        start_date = curr_start_date
                    if i < rs_len-1:
                        end_date = results_set[i+1]['changeDate']+timedelta(days=-1)
                    else:
                        end_date = datetime.now().date()
    for col in filters['type_col']:
        if description is None:
            if len(clusters) == 0 and len(models) == 0:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(date__lte=end_date) &
                                                      Q(call_scenarios__in=call_scenarios)

                                                      ).values(col)
            elif len(clusters) > 0 and len(models) == 0:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(date__lte=end_date) &
                                                      Q(cluster__in=clusters) &
                                                      Q(call_scenarios__in=call_scenarios)
                                                      ).values(col)

            elif len(clusters) == 0 and len(models) > 0:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(date__lte=end_date) &
                                                      Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                      Q(call_scenarios__in=call_scenarios)

                                                      ).values(col)
            else:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(date__lte=end_date) &
                                                      Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                      Q(cluster__in=clusters) &
                                                      Q(call_scenarios__in=call_scenarios)

                                                      ).values(col)

        else:
            if len(clusters) == 0 and len(models) == 0:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(Q(origModelDescription__icontains=description) | Q(
                                                          destModelDescription__icontains=description)) &
                                                      Q(date__lte=end_date) &
                                                      Q(call_scenarios__in=call_scenarios)

                                                      ).values(col)
            elif len(clusters) > 0 and len(models) == 0:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(date__lte=end_date) &
                                                      Q(Q(origModelDescription__icontains=description) | Q(
                                                          destModelDescription__icontains=description)) &
                                                      Q(cluster__in=clusters) &
                                                      Q(call_scenarios__in=call_scenarios)

                                                      ).values(col)
            elif len(clusters) == 0 and len(models) > 0:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(date__lte=end_date) &
                                                      Q(Q(origModelDescription__icontains=description) | Q(
                                                          destModelDescription__icontains=description)) &
                                                      Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                      Q(call_scenarios__in=call_scenarios)

                                                      ).values(col)
            else:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(date__lte=end_date) &
                                                      Q(Q(origModelDescription__icontains=description) | Q(
                                                          destModelDescription__icontains=description)) &
                                                      Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                      Q(cluster__in=clusters) &
                                                      Q(call_scenarios__in=call_scenarios)

                                                      ).values(col)
        types = []
        for q in types_query:
            if q[col] not in types:
                types.append(q[col])
                
        list_query_data = []
        for typ in types:
            if description is None:
                if len(clusters) == 0 and len(models) == 0:
                    query_res = CucmData.objects.filter(Q(date__gte=start_date) &
                                                        Q(date__lte=end_date) &
                                                        Q(**{col: typ}) &
                                                        Q(call_scenarios__in=call_scenarios)

                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                            call_count=Sum(filters['count_col']))
                elif len(clusters) > 0 and len(models) == 0:
                    query_res = CucmData.objects.filter(Q(date__gte=start_date) &
                                                        Q(date__lte=end_date) &
                                                        Q(cluster__in=clusters) &
                                                        Q(**{col: typ}) &
                                                        Q(call_scenarios__in=call_scenarios)

                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                            call_count=Sum(filters['count_col']))

                elif len(clusters) == 0 and len(models) > 0:
                    query_res = CucmData.objects.filter(Q(date__gte=start_date) &
                                                        Q(date__lte=end_date) &
                                                        Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                        Q(**{col: typ}) &
                                                        Q(call_scenarios__in=call_scenarios)

                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                            call_count=Sum(filters['count_col']))
                else:
                    query_res = CucmData.objects.filter(Q(date__gte=start_date) &
                                                        Q(date__lte=end_date) &
                                                        Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                        Q(cluster__in=clusters) &
                                                        Q(**{col: typ}) &
                                                        Q(call_scenarios__in=call_scenarios)

                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                            call_count=Sum(filters['count_col']))

            else:
                if len(clusters) == 0 and len(models) == 0:
                    query_res = CucmData.objects.filter(Q(plot=plot) &
                                                        Q(date__gte=start_date) &
                                                        Q(Q(origModelDescription__icontains=description) | Q(
                                                            destModelDescription__icontains=description)) &
                                                        Q(date__lte=end_date) &
                                                        Q(**{col: typ}) &
                                                        Q(call_scenarios__in=call_scenarios)

                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                        call_count=Sum(filters['count_col']))
                elif len(clusters) > 0 and len(models) == 0:
                    query_res = CucmData.objects.filter(Q(date__gte=start_date) &
                                                        Q(date__lte=end_date) &
                                                        Q(Q(origModelDescription__icontains=description) | Q(
                                                            destModelDescription__icontains=description)) &
                                                        Q(cluster__in=clusters) &
                                                        Q(**{col: typ}) &
                                                        Q(call_scenarios__in=call_scenarios)

                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                        call_count=Sum(filters['count_col']))
                elif len(clusters) == 0 and len(models) > 0:
                    query_res = CucmData.objects.filter(Q(date__gte=start_date) &
                                                        Q(date__lte=end_date) &
                                                        Q(Q(origModelDescription__icontains=description) | Q(
                                                            destModelDescription__icontains=description)) &
                                                        Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                        Q(**{col: typ}) &
                                                        Q(call_scenarios__in=call_scenarios)

                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                        call_count=Sum(filters['count_col']))
                else:
                    query_res = CucmData.objects.filter(Q(date__gte=start_date) &
                                                        Q(date__lte=end_date) &
                                                        Q(Q(origModelDescription__icontains=description) | Q(
                                                            destModelDescription__icontains=description)) &
                                                        Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                        Q(cluster__in=clusters) &
                                                        Q(**{col: typ}) &
                                                        Q(call_scenarios__in=call_scenarios)

                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                        call_count=Sum(filters['count_col']))

            if typ and typ == "no type":
                typ = plot
            obj = {}
            obj['type'] = typ
            obj['query_data'] = query_res
            list_query_data.append(obj)
        end_date = end_date + timedelta(days=-1)
        datasets = []
        for q_data in list_query_data:
            res_data = re_arrange_dates(q_data['query_data'], q_data['type'], start_date, end_date, plot)
            cucm_versions = []
            cucmversion_data = Cucmversion.objects.filter(cluster__in=clusters).values('version','changeDate').order_by("-changeDate")
            # return cucmversion_data
            isChanged = False
            for i in range(len(cucmversion_data)):
                '''
                if i ==0 :
                    if cucmversion_data[i]['changeDate'] < start_date:
                        cucmversion_data[i]['changeDate'] = start_date
                '''
                if cucmversion_data[i]['changeDate'] < start_date and not isChanged:
                    cucmversion_data[i]['changeDate'] = start_date
                    isChanged = True

                obj = {}
                obj['version'] = cucmversion_data[i]['version']
                obj['date'] = cucmversion_data[i]['changeDate'].strftime("%b %d %Y")
                cucm_versions.append(obj)
            res_data['versions'] = filter_cucmversions(cucm_versions)
            datasets.append(res_data)
    
    if len(filters['type_col']) > 1:
        datasets = get_sum_of_sub_data(datasets)
    res = {}
    if len(datasets) > 0:
        res['dataset'] = datasets
        res['labels'] = datasets[0]['labels']
        res['graphTypes'] = get_graph_types(plot)
        res['yLabel'] = get_ylabels(plot)

    if not res:
        return None
    else:
        return res

def get_cucmdevinfo(cluster,plot,actualmodel=None):
    res = {}
    device_calsses = []
    types = []
    if plot == "Device Registration Status":
        val = "Status"
    elif plot == "Device UnRegistration Reason":
        val = "StatusReason"
    vals = val,"DeviceClass",

    if len(cluster) == 0 and actualmodel:
        types_data = CucmDeviceStatus.objects.filter(ActualModel__in=actualmodel.split(',')).values(*vals)

    elif len(cluster) > 0 and not actualmodel:
        types_data = CucmDeviceStatus.objects.filter(Cluster__in=cluster.split(',')).values(*vals)

    elif len(cluster) > 0 and actualmodel:
        types_data = CucmDeviceStatus.objects.filter(ActualModel__in=actualmodel.split(','),Cluster__in = cluster.split(',')).values(*vals)
    else:
        types_data = CucmDeviceStatus.objects.values(*vals)

    if types_data  and len(types_data)>0:
        for t in types_data:
            if t[val] not in types:
                types.append(t[val])
            if t['DeviceClass'] not in device_calsses:
                device_calsses.append(t['DeviceClass'])
    if plot == "Device UnRegistration Reason":
        types.remove("Registered")
    datasets = []
    for typ in types:
        data = []
        devices =[]
        for dc in device_calsses:
            if cluster:
                res_data = CucmDeviceStatus.objects.filter(Cluster__in = cluster.split(','), DeviceClass=dc).filter(**{val: typ}).values("Name","TimeStamp").annotate(cnt = Sum("count"))
            else:
                res_data = CucmDeviceStatus.objects.filter(DeviceClass=dc).filter(**{val: typ}).values("Name","TimeStamp").annotate(cnt = Sum("count"))
            if res_data and len(res_data) >0:
                cnt = 0
                devs = []
                device_st = ""
                for rd in res_data:
                    cnt += rd['cnt']
                    ob = {}
                    ob['Device Name'] = rd['Name']
                    ob['TimeStamp'] = rd["TimeStamp"]
                    devs.append(ob)
                    device_st += rd['Name'] +', '
                data.append(cnt)
                #devices.append(devs)
                devices.append(device_st)
            else:
                data.append(0)
                devices.append([])
            
        obj = {}
        obj['cases'] = devices
        obj['data'] = data
        obj['label'] = typ
        datasets.append(obj)
    res['dataset'] = datasets
    res['labels'] = device_calsses
    res['graphTypes'] = ["HorizontalBar","Stacked"]
    res['yLabel'] = "Count"
    
    return res

def get_topology_data(cluster):
    ret_res = {}
    links = []
    
    if cluster:
        query_res = CucmTrunk.objects.filter(cluster__in = cluster.split(',')).values("source","destination","name","src_destination")
    else:
        query_res = CucmTrunk.objects.values("source","destination","name","src_destination")
    i = 1
    target__obj = {}
    src_dest_obj = {}
    target_arr = []
    for q in query_res:
        if cluster is not None:
            cucm_data = CucmData.objects.filter(Q(date__gte = datetime.now().date()) &
                                                Q(cluster__in = cluster.split(',')) &
                                            Q(Q(origDeviceName = q['name']) | Q(destDeviceName = q['name'])))
        else:
            cucm_data = CucmData.objects.filter(Q(date__gte = datetime.now().date()) &
                                            Q(Q(origDeviceName = q['name']) | Q(destDeviceName = q['name'])))
        
        if q['destination'] not in target_arr:
            link_obj = {}
            link_obj['source'] = {'id': 0, 'label':cluster}
            link_obj['target'] = {'id':i, 'label':q['destination']}
            link_obj['value'] = q['name']
            link_obj['count'] = len(cucm_data)
            link_obj['src_destination'] = [q['src_destination']]
            src_dest_obj[q['destination']] = [q['src_destination']]
            links.append(link_obj)
            
            target_arr.append(q['destination'])
            target__obj[q['destination']] = i
            i = i+1
        else:
            link_obj = {}
            link_obj['source'] = {'id': 0, 'label':cluster}
            link_obj['target'] = {'id':target__obj[q['destination']], 'label':q['destination']}
            link_obj['value'] = q['name']
            link_obj['count'] = len(cucm_data)
            src_dest_obj[q['destination']].append(q['src_destination'])
            links.append(link_obj)
    ret_res['graphTypes'] = ["Topology"]
    ret_res['dataset'] = {"edges":links}
    ret_res['src_destinations'] = src_dest_obj
    return ret_res

def get_cucm_data(plot, cluster, start_date, end_date, version, model, description, mavg, num_users,
                  plotendpoints=None):
    
    filters = get_cucm_filters(plot)
    clusters = []
    val = "date",
    if cluster is not None:
        clusters = cluster.split(',')
        val = "date", "version",
    if plotendpoints:
        val = "date",
    if plot == "Call Failure Causes":
        val = "date", "globalCallID_callId", "callingPartyNumber", "finalCalledPartyNumber", "dateTimeOrigination"
    
    models = []
    if model is not None:
        models = model.split(',')

    if plot in ["Device Registration Status", "Device UnRegistration Reason"]:
        return get_cucmdevinfo(cluster, plot,model)
    
    if plot == "Topology":
        return get_topology_data(cluster)

    if plot in ["Hybrid Calls", "Webex Meeting", "Webex Conference"]:
        return get_hybrid_data(plot, cluster, start_date, end_date, version, model, description, mavg, num_users,
                               plotendpoints)
    if plot == "Users":
        return get_users_data(clusters,plot)
    
    if plot == "Secure Audio~Video Calls":
        secure_col_filter = ["Secured"]
    else:
        secure_col_filter = ["Secured", "Non-secure", "Authenticated"]

    if plot == "Audio (Secured~Non-Secured)":
        secure_filter = ["Audio"]
    else:
        secure_filter = ["Audio" , "Video"]

    if plot == "Video (Secured~Non-Secured)":
        secure_filter_video = ["Video"]
    else:
        secure_filter_video = ["Audio" , "Video"]

    if version is not None:
        if cluster and "CUCM" in cluster and len(cluster) > len("CUCM"):
            cluster = None
            clusters=[]
            results_set = Cucmversion.objects.filter(version__icontains=version).values("changeDate","version","cluster").order_by("changeDate")
            cluster_res = Cucmversion.objects.filter(version__icontains=version).values("cluster")
            new_clusters = []
            if cluster_res is not None and len(cluster_res)>0:
                for cr in cluster_res:
                    new_clusters.append(cr['cluster'])
                clusters = new_clusters
        else:
            results_set = Cucmversion.objects.filter(cluster__in=clusters,version__icontains=version).values("changeDate","version").order_by("changeDate")
        if results_set is not None and len(results_set)>0:
            rs_len = len(results_set)
            start_date = datetime.now().date()
            for i in range(len(results_set)):
                if version in results_set[i]['version']:
                    curr_start_date = results_set[i]['changeDate']
                    if curr_start_date < start_date:
                        start_date = curr_start_date
                    if i < rs_len-1:
                        end_date = results_set[i+1]['changeDate']+timedelta(days=-1)
                    else:
                        end_date = datetime.now().date()
    
    for col in filters['type_col']:
        if plot in ["Top Active Users", "Least Active Users"]:
            val = col,
        if description is None:
            if len(clusters) == 0 and len(models) == 0:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(date__lte=end_date) &
                                                      Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                      ).values(col)
            elif len(clusters) > 0 and len(models) == 0:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(date__lte=end_date) &
                                                      Q(cluster__in=clusters) &
                                                      Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                      ).values(col)

            elif len(clusters) == 0 and len(models) > 0:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(date__lte=end_date) &
                                                      Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                      Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                      ).values(col)
            else:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(date__lte=end_date) &
                                                      Q(Q(origModel__in=models) | Q(destModel__in=models)) &

                                                      Q(cluster__in=clusters) &
                                                      Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                      ).values(col)

        else:
            if len(clusters) == 0 and len(models) == 0:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(Q(origModelDescription__icontains=description) | Q(
                                                          destModelDescription__icontains=description)) &
                                                      Q(date__lte=end_date) &
                                                      Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                      ).values(col)
            elif len(clusters) > 0 and len(models) == 0:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(date__lte=end_date) &
                                                      Q(Q(origModelDescription__icontains=description) | Q(
                                                          destModelDescription__icontains=description)) &
                                                      Q(cluster__in=clusters) &
                                                      Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                      ).values(col)
            elif len(clusters) == 0 and len(models) > 0:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(date__lte=end_date) &
                                                      Q(Q(origModelDescription__icontains=description) | Q(
                                                          destModelDescription__icontains=description)) &
                                                      Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                      Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                      ).values(col)
            else:
                types_query = CucmData.objects.filter(Q(date__gte=start_date) &
                                                      Q(date__lte=end_date) &
                                                      Q(Q(origModelDescription__icontains=description) | Q(
                                                          destModelDescription__icontains=description)) &
                                                      Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                      Q(cluster__in=clusters) &
                                                      Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                      ).values(col)
        types = []
        for q in types_query:
            if q[col] not in types:
                types.append(q[col])
        unwanted_types = ["No Error", "Normal call clearing", "Unknown", "SIP Trunk", "MGCP Trunk",
                              "Cisco Meeting Server", "Conference Bridge", "Others", "Call split (Cisco Specific)", None]
        
        trunk_query = CucmTrunk.objects.filter(cluster__in = clusters).values("name")
        if trunk_query is not None and len(trunk_query)>0:
            for tq in trunk_query:
                if tq['name'] not in unwanted_types:
                    unwanted_types.append(tq['name'])
                    
        for ut in unwanted_types:
            if ut in types:
                types.remove(ut)
                
        list_query_data = []
        for typ in types:
            if description is None:
                if len(clusters) == 0 and len(models) == 0:
                    query_res = CucmData.objects.filter(Q(date__gte=start_date) &
                                                        Q(date__lte=end_date) &
                                                        Q(**{col: typ}) &
                                                        Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                            call_count=Sum(filters['count_col']))
                elif len(clusters) > 0 and len(models) == 0:
                    query_res = CucmData.objects.filter(Q(date__gte=start_date) &
                                                        Q(date__lte=end_date) &
                                                        Q(cluster__in=clusters) &
                                                        Q(**{col: typ}) &
                                                        Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                            call_count=Sum(filters['count_col']))

                elif len(clusters) == 0 and len(models) > 0:
                    query_res = CucmData.objects.filter(Q(date__gte=start_date) &
                                                        Q(date__lte=end_date) &
                                                        Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                        Q(**{col: typ}) &
                                                        Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                            call_count=Sum(filters['count_col']))
                else:
                    query_res = CucmData.objects.filter(Q(date__gte=start_date) &
                                                        Q(date__lte=end_date) &
                                                        Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                        Q(cluster__in=clusters) &
                                                        Q(**{col: typ}) &
                                                        Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                            call_count=Sum(filters['count_col']))

            else:
                if len(clusters) == 0 and len(models) == 0:
                    query_res = CucmData.objects.filter(Q(plot=plot) &
                                                        Q(date__gte=start_date) &
                                                        Q(Q(origModelDescription__icontains=description) | Q(
                                                            destModelDescription__icontains=description)) &
                                                        Q(date__lte=end_date) &
                                                        Q(**{col: typ}) &
                                                        Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                            call_count=Sum(filters['count_col']))
                elif len(clusters) > 0 and len(models) == 0:
                    query_res = CucmData.objects.filter(Q(date__gte=start_date) &
                                                        Q(date__lte=end_date) &
                                                        Q(Q(origModelDescription__icontains=description) | Q(
                                                            destModelDescription__icontains=description)) &
                                                        Q(cluster__in=clusters) &
                                                        Q(**{col: typ}) &
                                                        Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                            call_count=Sum(filters['count_col']))
                elif len(clusters) == 0 and len(models) > 0:
                    query_res = CucmData.objects.filter(Q(date__gte=start_date) &
                                                        Q(date__lte=end_date) &
                                                        Q(Q(origModelDescription__icontains=description) | Q(
                                                            destModelDescription__icontains=description)) &
                                                        Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                        Q(**{col: typ}) &
                                                        Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                            call_count=Sum(filters['count_col']))
                else:
                    query_res = CucmData.objects.filter(Q(date__gte=start_date) &
                                                        Q(date__lte=end_date) &
                                                        Q(Q(origModelDescription__icontains=description) | Q(
                                                            destModelDescription__icontains=description)) &
                                                        Q(Q(origModel__in=models) | Q(destModel__in=models)) &
                                                        Q(cluster__in=clusters) &
                                                        Q(**{col: typ}) &
                                                        Q(fmtSecureStat__in=secure_col_filter)&
                                                      Q(fmtAVType__in=secure_filter)&
                                                      Q(fmtAVType__in=secure_filter_video)
                                                        ).extra({'date': "date(date)"}).values(*val).annotate(
                                                            call_count=Sum(filters['count_col']))
            if typ and typ == "no type":
                typ = plot
            if typ and "TelePresence" in typ:
                typ = typ.replace("TelePresence", "TP")
            if typ and "Unified Client Services Framework" in typ:
                typ = typ.replace("Unified Client Services Framework", "UCSF")
            obj = {}
            obj['type'] = typ
            obj['query_data'] = query_res
            list_query_data.append(obj)

        end_date = end_date + timedelta(days=-1)
        datasets = []
        for q_data in list_query_data:
            if plot in ['Top Active Users', 'Least Active Users']:
                if len(q_data['query_data']) > 0:
                    datasets.append(q_data['query_data'][0])
            else:
                res_data = re_arrange_dates(q_data['query_data'], q_data['type'], start_date, end_date, plot)
                cucm_versions = []
                cucmversion_data = Cucmversion.objects.filter(cluster__in=clusters).values('version','changeDate').order_by("-changeDate")
                isChanged=False
                for i in range(len(cucmversion_data)):
                    if cucmversion_data[i]['changeDate'] < start_date and not isChanged:
                        cucmversion_data[i]['changeDate'] = start_date
                        isChanged=True
                    
                    obj = {}
                    obj['version'] = cucmversion_data[i]['version']
                    obj['date'] = cucmversion_data[i]['changeDate'].strftime("%b %d %Y")
                    cucm_versions.append(obj)
                res_data['versions'] = filter_cucmversions(cucm_versions)
                datasets.append(res_data)
    
    if plot in ['Top Active Users', 'Least Active Users']:
        return get_activeUsers_data(datasets, plot, num_users)

    if len(filters['type_col']) > 1:
        datasets = get_sum_of_sub_data(datasets)
    
    res = {}
    if len(datasets) > 0:
        if mavg == "True" or plot in ["Talktime"]:
            datasets.append(Calculate_Moving_Average(datasets[0]['data']))
        if plot == "Endpoints Participation":
            datasets = extract_model_series(datasets)
        res['dataset'] = datasets
        res['labels'] = datasets[0]['labels']
        res['graphTypes'] = get_graph_types(plot)
        res['yLabel'] = get_ylabels(plot)

    if not res:
        return None
    else:
        if plot == "Call Success~Rate":
            res['dataset'] = get_total_percentages(res)
            # res['dataset'].append(Calculate_Moving_Average(res['dataset'][0]['data']))
        return res