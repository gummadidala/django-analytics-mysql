from rest_framework import serializers
from itcucm.models import *
class CucmCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = CucmCategory
        fields = ['type','key']
        
        
class CucmGeneralSerializer(serializers.ModelSerializer):
    type = serializers.SlugRelatedField(
        queryset=CucmCategory.objects.all(),
        slug_field='type')
    class Meta:
        model = CucmGeneral
        fields = ['type','name','value','key']
