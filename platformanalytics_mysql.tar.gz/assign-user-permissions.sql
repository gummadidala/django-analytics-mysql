USE mysql;
CREATE USER 'dbadmin'@'localhost' IDENTIFIED BY 'db1234';
GRANT ALL PRIVILEGES ON *.* TO 'dbadmin'@'localhost'
WITH GRANT OPTION;

CREATE USER 'dbadmin'@'%' IDENTIFIED BY 'db1234';
GRANT ALL PRIVILEGES ON *.* TO 'dbadmin'@'%'
WITH GRANT OPTION;

SELECT user, host FROM user;

CREATE DATABASE analytics;
