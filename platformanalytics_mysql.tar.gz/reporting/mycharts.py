'''
Created on 01-Dec-2017

@author: Koteswararao Gummadidala
'''

import matplotlib
matplotlib.use('Agg')
import matplotlib as mpl
from matplotlib import font_manager as fm
import matplotlib.pyplot as plt
import os, json, sys,math
import requests
import traceback,sys
plots_path = '/tmp/'


def normalize_datasets(datasets):
    if 'dataset' in datasets:
        for ds in datasets['dataset']:
            data = []
            for d in ds['data']:
                data.append(int(d))
            ds['data'] = data
    return datasets
        
def generate_stacked_plot(data_sets, plot_name, fmt):
    data_sets= normalize_datasets(data_sets)
    try:
        file_name = plot_name+'.'+fmt
        file_path = plots_path+file_name
        if os.path.exists(file_path):
            os.remove(file_path)
            
        x_labels = data_sets['labels']
        N = len(x_labels)
        ind = [x for x in range(N)]
        width = 0.7    
        #plt.ylabel('Call count')
        r_len = len(x_labels)
        d = int(math.ceil(r_len / 10))
        x_labels = [x_labels[i] for i in range(0,r_len) if i%d==0]
        bin_len = len(x_labels)
        for i in range(r_len-len(x_labels)):
            x_labels.append("")
            
        plt.xticks(ind, x_labels, fontsize=4)
        datas = []
        labels = []
        i = 0
        for i in range(len(data_sets['dataset'])):
            if i==0:
                datas.append(plt.bar(ind, data_sets['dataset'][i]['data'], width))
            else:
                datas.append(plt.bar(ind, data_sets['dataset'][i]['data'], width, bottom=data_sets['dataset'][i-1]['data']))
            labels.append(data_sets['dataset'][i]['label'])
        
        
        plt.locator_params(nbins=bin_len,axis = 'x')
        plt.legend(tuple([p[0] for p in datas]), tuple([l for l in labels]))
        plt.savefig(file_path,dpi = 600)
        plt.clf()
        
        return file_path
    except:
        tb = traceback.format_exc()
        print tb
        print str(sys.exc_info()[0])
        print "Error while creating stacked plot",plot_name
        return None

def generate_barline_plot(data_sets, plot_name, fmt):
    data_sets= normalize_datasets(data_sets)
    try:
        file_name = plot_name+'.'+fmt
        file_path = plots_path+file_name
        if os.path.exists(file_path):
            os.remove(file_path)
        
        x_labels = data_sets['labels']
       
        N = len(x_labels)
        ind = [x for x in range(N)]
        width = 0.7    
        #plt.ylabel('Call count')
        r_len = len(x_labels)
        d = int(math.ceil(r_len / 10))
        x_labels = [x_labels[i] for i in range(0,r_len) if i%d==0]
        bin_len = len(x_labels)
        for i in range(r_len-len(x_labels)):
            x_labels.append("")
        plt.xticks(ind, x_labels, fontsize=4)
        plt.locator_params(nbins=bin_len,axis = 'x')
        plt.bar(ind, data_sets['dataset'][0]['data'], width)
        plt.plot(data_sets['dataset'][1]['data'],color='r')
        plt.savefig(file_path,dpi = 600)
        plt.clf()
        return file_path
    except:
        print "Error while creating barline plot",plot_name
        return None

def generate_pie_plot(data_sets, plot_name, fmt):
    data_sets= normalize_datasets(data_sets)
    try:
        
        file_name = plot_name+'.'+fmt
        file_path = plots_path+file_name
        if os.path.exists(file_path):
            os.remove(file_path)
        labels = data_sets['labels']
        sizes = [d['data'][0] for d in data_sets['dataset']]
        plt.pie(sizes,labels = labels,startangle=90,autopct= lambda(p) : '{:.0f}'.format(p*sum(sizes)/100))
        plt.axis("equal")
        plt.savefig(file_path,dpi = 600)
        plt.clf()
        return file_path
    except:
        print "Error while creating pie plot",plot_name
        return None

def generate_hstacked_plot(data_sets, plot_name, fmt):
    data_sets= normalize_datasets(data_sets)
    try:
        file_name = plot_name+'.'+fmt
        file_path = plots_path+file_name
        if os.path.exists(file_path):
            os.remove(file_path)
            
        y_labels = data_sets['labels']
        N = len(y_labels)
        ind = [x for x in range(N)]
        width = 0.7    
        #plt.ylabel('Call count')
        plt.yticks(ind, y_labels, fontsize=4)
        datas = []
        labels = []
        i = 0
        for i in range(len(data_sets['dataset'])):
            if i==0:
                datas.append(plt.barh(ind, data_sets['dataset'][i]['data'], width))
            else:
                datas.append(plt.barh(ind, data_sets['dataset'][i]['data'], width, left=data_sets['dataset'][i-1]['data']))
            labels.append(data_sets['dataset'][i]['label'])
        
        plt.legend(tuple([p[0] for p in datas]), tuple([l for l in labels]))
        plt.tight_layout()
        plt.savefig(file_path,dpi = 600)
        plt.clf()
        return file_path
    except:
        print "Error while creating horizontal stacked plot",plot_name
        '''
        tb = traceback.format_exc()
        print tb
        '''
        return None

def generate_heatmap_plot(data_sets, plot_name, fmt):
    data_sets= normalize_datasets(data_sets)
    try:
        file_name = plot_name+'.'+fmt
        file_path = plots_path+file_name
        if os.path.exists(file_path):
            os.remove(file_path)
            
        column_labels = []
        row_labels = data_sets['labels']
        data = []
    
        for r in data_sets['dataset']:
            data.append(r['data'])
            column_labels.append(r['label'])
        fig, ax = plt.subplots()
        
        r_len = len(row_labels)
        d = int(math.ceil(r_len / 10))
        row_labels = [row_labels[i] for i in range(0,r_len) if i%d==0]
        bin_len = len(row_labels)
        for i in range(r_len-len(row_labels)):
            row_labels.append("")
        
        heatmap = ax.pcolor(data, cmap=plt.cm.Blues)
        #return Response(data,status=HTTP_200_OK)
        
        x_label_position = [x+0.5 for x in range(len(column_labels))]
        y_label_position = [y+0.5 for y in range(len(row_labels))]
        
        ax.set_yticks(x_label_position, minor=False)
        ax.set_xticks(y_label_position, minor=False)
        
        
        ax.set_xticklabels(row_labels, minor=False,fontsize = 4)
        ax.set_yticklabels(column_labels, minor=False,fontsize = 4)
        plt.locator_params(nbins=bin_len,axis = 'x')
        plt.tight_layout()
        c = plt.pcolor(data, edgecolors='w', linewidths=0.8, cmap='GnBu')
        plt.colorbar(c)
        plt.savefig(file_path,dpi = 600)
        plt.clf()
        return file_path
    except:
        '''
        tb = traceback.format_exc()
        print tb
        print str(sys.exc_info()[0])
        '''
        print "error while creating heatmap",plot_name
        return None

def generate_pieDoughnut_plot(data_sets, plot_name, fmt):
    data_sets= normalize_datasets(data_sets)
    try:
        file_name = plot_name+'.'+fmt
        file_path = plots_path+file_name
        if os.path.exists(file_path):
            os.remove(file_path)
            
        outer = {}
        outer['labels'] = []
        outer['data'] = []
        inner = {}
        inner['labels'] = []
        inner['data'] = []
        sub_data_lens = []
        for ds in data_sets['subData']:
            if ds['nodeData']['population'] >0:
                inner['labels'].append(ds['nodeData']['age'])
                inner['data'].append(ds['nodeData']['population'])
                sub_data_lens.append(len(ds['subData']))
                for d in ds['subData']:
                    outer['labels'].append(d['nodeData']['age'])
                    outer['data'].append(d['nodeData']['population'])
                
        fig, ax = plt.subplots()
        ax.axis('equal')
        width = 0.3
        cm = plt.get_cmap("tab20c")
        
       
        cincodes = [i*4 for i in range(len(inner['labels']))]
        cin = cm(cincodes)
        coutcodes = []
        k=0
        for j in sub_data_lens:
            c = cincodes[k]
            for i in range(j):
                coutcodes.append(c+i)
            k = k+1
        cout = cm(coutcodes)
        proptease = fm.FontProperties()
        proptease.set_size('xx-small')
        mpl.rcParams['font.size']=5
        pie, _ = ax.pie(outer['data'], radius=1, labels=outer['labels'], colors=cout, labeldistance=0.75)
        plt.setp( pie, width=width, edgecolor='white')
        
        pie2, _ = ax.pie(inner['data'], radius=1-width, labels=inner['labels'],
                                              labeldistance=0.4, colors=cin)
        
        plt.savefig(file_path,dpi = 600)
        plt.clf()
        return file_path
    except:
        '''
        tb = traceback.format_exc()
        print tb
        print str(sys.exc_info()[0])
        '''
        print "Error while creating pie doughnut plot",plot_name
        return None
