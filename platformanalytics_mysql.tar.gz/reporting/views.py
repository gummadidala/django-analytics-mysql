from rest_framework import parsers, renderers
from rest_framework import generics
from rest_framework.authtoken.models import Token
from rest_framework.authtoken.serializers import AuthTokenSerializer
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.status import HTTP_201_CREATED, HTTP_400_BAD_REQUEST, HTTP_200_OK
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
import django_filters
from rest_framework import filters
from reporting.serializers import *
from reporting.models import *
from reporting.utils import *
from reporting.tasks import *

class ReportFormatAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = ReportFormatSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return ReportFormat.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ReportFormatSerializer
        return ReportFormatSerializer

class ReportDestinationAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = ReportDestinationSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('name',)
    search_fields = ('name',)
    lookup_field = 'key'
    def get_queryset(self):
        return ReportDestination.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ReportDestinationSerializer
        return ReportDestinationSerializer

class SchedulingAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = SchedulingSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('key','product__name','product__key',)
    search_fields = ('key','product__name','product__key',)
    lookup_field = 'key'
    def get_queryset(self):
        return Scheduling.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return SchedulingWriteSerializer
        return SchedulingSerializer
        
class SchedulingUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = SchedulingSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('key','product__name','product__key',)
    search_fields = ('key','product__name','product__key',)
    lookup_field = 'key'
    def get_queryset(self):
        return Scheduling.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return SchedulingWriteSerializer
        return SchedulingSerializer

class ReportingAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = ReportingSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('key','account_user__key','report_format__name','destination_to_report__name')
    search_fields = ('key','account_user__key','report_format__name','destination_to_report__name')
    lookup_field = 'key'
    def get_queryset(self):
        return Reporting.objects.all()
    def post(self,request,format=None):
        usr = self.request.user.username
        parsed_data = request.data
        parsed_data['account_user'] = str(AccountUser.objects.filter(account_user__username=usr)[0].key)
        if 'time_to_report' in parsed_data:
            time_schedule = TimeScheduleSerializer().create(parsed_data['time_to_report'])
            parsed_data['time_to_report'] = str(time_schedule.key)
        serializer = ReportingWriteSerializer(data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            reporting_job_creation.delay(str(serializer.instance.key))
            return Response(serializer.data,status=HTTP_201_CREATED)
            
class ReportingUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = ReportingSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    filter_fields = ('key','account_user__key','report_format__name','destination_to_report__name')
    search_fields = ('key','account_user__key','report_format__name','destination_to_report__name')
    lookup_field = 'key'
    def get_queryset(self):
        return Reporting.objects.all()
    def patch(self,request,key,format=None):
        parsed_data = request.data
        reporting_obj = Reporting.objects.get(key=key)
        time_schedule_obj = reporting_obj.time_to_report
        if 'time_to_report' in parsed_data:
            time_schedule = TimeScheduleSerializer().update(time_schedule_obj,parsed_data['time_to_report'])
            parsed_data['time_to_report'] = str(time_schedule.key)
        serializer = ReportingWriteSerializer(reporting_obj,data=parsed_data)
        if serializer.is_valid():
            serializer.save()
            periodic_task_obj = PeriodicTask.objects.filter(id=reporting_obj.task_obj)
            if periodic_task_obj is not None and len(periodic_task_obj)>0:
                periodic_task_obj[0].enabled = reporting_obj.enabled
                crontab_schedule_obj = periodic_task_obj[0].crontab
                if crontab_schedule_obj:
                    time_to_report = TimeSchedule.objects.get(key=parsed_data['time_to_report'])
                    crontab_schedule_obj.minute =  time_to_report.minute
                    crontab_schedule_obj.hour = time_to_report.hour
                    crontab_schedule_obj.month_of_year = time_to_report.month
                    crontab_schedule_obj.day_of_month = time_to_report.dayOfMonth
                    crontab_schedule_obj.day_of_week = time_to_report.dayOfWeek
                    crontab_schedule_obj.save()
                periodic_task_obj[0].save()
            return Response(serializer.data,status=HTTP_201_CREATED)
        return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)
    
class TimeScheduleAPIView(generics.ListCreateAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = TimeScheduleSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    lookup_field = 'key'
    def get_queryset(self):
        usr = self.request.user.username
        acct_user = AccountUser.objects.filter(account_user__username=usr)
        gen_plots(str(acct_user[0].key))
        return TimeSchedule.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return TimeScheduleSerializer
        return TimeScheduleSerializer
    
class TimeScheduleUpdateAPIView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = (TokenAuthentication,)
    #authentication_classes = (ExpiringTokenAuthentication,)
    permission_classes = (IsAuthenticated,)
    serializer_class = TimeScheduleSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter,)
    lookup_field = 'key'
    def get_queryset(self):
        return TimeSchedule.objects.all()
    def get_serializer_class(self):
        if self.request.method == 'PUT' or self.request.method == 'PATCH':
            return TimeScheduleSerializer
        return TimeScheduleSerializer