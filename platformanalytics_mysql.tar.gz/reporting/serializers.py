'''
Created on 18-Sept-2017

@author: Koteswararao Gummadidala
'''
from rest_framework import serializers
from reporting.models import *
from common.serializers import *
from django_celery_beat.models import CrontabSchedule, PeriodicTask

class PeriodicTaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = PeriodicTask
        fields = ['name','task']

class ReportFormatSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportFormat
        fields = ['key', 'name']

class ReportDestinationSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportDestination
        fields = ['key', 'name']


class TimeScheduleSerializer(serializers.ModelSerializer):
    class Meta:
        model = TimeSchedule
        fields = ['key', 'minute', 'hour', 'dayOfMonth', 'month','dayOfWeek']

class SchedulingSerializer(serializers.ModelSerializer):
    product = ProductShortSerializer()
    modified_by = AccountUserSerializer()
    time_to_report = TimeScheduleSerializer()
    class Meta:
        model = Scheduling
        fields = ['key','last_modified','product','modified_by','schedule_frequency']

class SchedulingWriteSerializer(serializers.ModelSerializer):
    product = serializers.SlugRelatedField(
        queryset=Product.objects.all(),
        slug_field='key')
    modified_by = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key',required=False)
    time_to_report = serializers.SlugRelatedField(
        queryset=TimeSchedule.objects.all(),
        slug_field='key')
    class Meta:
        model = Scheduling
        fields = ['key','last_modified','product','modified_by','schedule_frequency']
    def create(self,validated_data):
        usr = self.context['request'].user
        acct_user = AccountUser.objects.filter(account_user__username = usr.username)
        validated_data['modified_by'] = acct_user[0]
        return serializers.ModelSerializer.create(self,validated_data)
    def update(self, instance, validated_data):
        if 'schedule_frequency' in validated_data:
            instance.schedule_frequency = validated_data['schedule_frequency']
        if 'product' in validated_data:
            instance.product = validated_data['product']
        usr = self.context['request'].user
        acct_user = AccountUser.objects.filter(account_user__username = usr.username)
        instance.account_user = acct_user[0]
        instance.save()
        return instance

class ReportingSerializer(serializers.ModelSerializer):
    report_format = serializers.SlugRelatedField(
        queryset=ReportFormat.objects.all(),
        slug_field='name')
    destination_to_report = serializers.SlugRelatedField(
        queryset=ReportDestination.objects.all(),
        slug_field='name')
    account_user = AccountUserSerializer()
    time_to_report = TimeScheduleSerializer()
    class Meta:
        model = Reporting
        fields = ['key','account_user','report_format','destination_to_report','time_to_report', 'last_modified','destination_address','task_obj','enabled']

class ReportingWriteSerializer(serializers.ModelSerializer):
    report_format = serializers.SlugRelatedField(
        queryset=ReportFormat.objects.all(),
        slug_field='key')
    destination_to_report = serializers.SlugRelatedField(
        queryset=ReportDestination.objects.all(),
        slug_field='key')
    account_user = serializers.SlugRelatedField(
        queryset=AccountUser.objects.all(),
        slug_field='key',required=False)
    time_to_report = serializers.SlugRelatedField(
        queryset=TimeSchedule.objects.all(),
        slug_field='key')
    class Meta:
        model = Reporting
        fields = ['key','account_user','report_format','destination_to_report','time_to_report', 'last_modified','destination_address','task_obj','enabled']