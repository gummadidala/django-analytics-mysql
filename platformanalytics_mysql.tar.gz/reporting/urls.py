'''
Created on 15-Sept-2017

@author: Koteswararao Gummadidala
'''
from django.conf.urls import url
from reporting import views
urlpatterns = [
                url(r'^api/scheduling/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                    views.SchedulingUpdateAPIView.as_view()),
                url(r'^api/scheduling/', views.SchedulingAPIView.as_view()),
                url(r'^api/reporting/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                    views.ReportingUpdateAPIView.as_view()),
                url(r'^api/reporting/', views.ReportingAPIView.as_view()),
                url(r'^api/reportformat/', views.ReportFormatAPIView.as_view()),
                url(r'^api/reportdestination/', views.ReportDestinationAPIView.as_view()),
                url(r'^api/timeschedule/(?P<key>[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12})/$',
                    views.TimeScheduleUpdateAPIView.as_view()),
                url(r'^api/timeschedule/', views.TimeScheduleAPIView.as_view()),
                ]