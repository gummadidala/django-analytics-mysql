from __future__ import unicode_literals

from django.db import models
import uuid
from django.utils import timezone
from common.models import Product, AccountUser

# Create your models here.

class ReportFormat(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=64)

class ReportDestination(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=64)
    
class TimeSchedule(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    minute = models.TextField(default="*",null=True,blank=True)
    hour = models.TextField(default="3",null=True,blank=True)
    dayOfMonth = models.TextField(default="*",null=True,blank=True)
    month = models.TextField(default="*",null=True,blank=True)
    dayOfWeek = models.TextField(default="*",null=True,blank=True)

class Scheduling(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    last_modified = models.DateTimeField(default=timezone.now)
    product = models.ForeignKey(Product, default="", null=True,blank=True)
    modified_by = models.ForeignKey(AccountUser, default="", null=True,blank=True)
    schedule_frequency = models.ForeignKey(TimeSchedule, default="", null=True,blank=True)
    task_obj = models.CharField(max_length=128,default="",null=True,blank=True)
    enabled = models.BooleanField(default=True)
                           
class Reporting(models.Model):
    key = models.UUIDField(default=uuid.uuid4, editable=False)
    account_user = models.ForeignKey(AccountUser, default="", null=True,blank=True)
    report_format = models.ForeignKey(ReportFormat, default="", null=True,blank=True)
    destination_to_report = models.ForeignKey(ReportDestination, default="", null=True,blank=True)
    destination_address = models.TextField(default="",null=True,blank=True)
    time_to_report = models.ForeignKey(TimeSchedule, default="", null=True,blank=True)
    last_modified = models.DateTimeField(default=timezone.now)
    task_obj = models.CharField(max_length=128,default="",null=True,blank=True)
    enabled = models.BooleanField(default=True)