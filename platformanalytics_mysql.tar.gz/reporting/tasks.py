#import analytics.views
from reporting.models import *
from alphacucm.utils import *
from desk.utils import *
from cms.utils import *
from hybridtest.utils import *
from datetime import datetime
from reporting.mycharts import *
from reporting.utils import *
from django_celery_beat.models import CrontabSchedule, PeriodicTask
from celery import shared_task
import json

roomId = "Y2lzY29zcGFyazovL3VzL1JPT00vMzkzMWNhNTAtYzlmZS0xMWU3LWI2NzgtNWY5MzNjN2Y4YTVh"
text = "ctg-trials-analytics.cisco.com "
dash_board_url = "ctg-trials-analytics.cisco.com:8000/analytics/api/"

images_list = []
link_urls = []
titles = []

def get_file_path(data_sets,fn,graph_type):
    file_path = None
    if graph_type == "BarLine":
        file_path = generate_barline_plot(data_sets,fn,'png')
    if graph_type == "Stacked":
        file_path = generate_stacked_plot(data_sets,fn,'png')
    elif graph_type == "Pie":
        file_path = generate_pie_plot(data_sets,fn,'png')
    elif graph_type == "PieDoughnut":
        file_path = generate_pieDoughnut_plot(data_sets,fn,'png')
    elif graph_type == "Heatmap":
        file_path = generate_heatmap_plot(data_sets,fn,'png')
    elif graph_type == "HorizontalBar":
        print data_sets
        file_path = generate_hstacked_plot(data_sets,fn,'png')
    return file_path
        
def generate_cucm_plots(plots,clusters,versions,start_date,end_date):
    del titles[:]
    del link_urls[:]
    del images_list[:]
    for plot in plots:
        graph_types = get_graph_types(plot)
        if graph_types[0] == "BarLine":
            mavg = "True"
        else:
            mavg = "False"
        fn = plot
        if len(clusters)>0:
            for cluster in clusters:
                fn = plot +'_'+ cluster
                if len(versions) >0 :
                    for version in versions:
                        fn = plot +'_'+ cluster +'_'+ version
                        url_link = dash_board_url+"plotcucm/?plot="+plot+"&start_date="+str(start_date)+"&end_date="+str(end_date)+"&cluster="+cluster+"&version="+version
                        url_link = url_link.replace(" ", "%20")
                        data_sets = get_cucm_data(plot, cluster, start_date, end_date, version, None, None, mavg)
                        if data_sets:
                            file_path = get_file_path(data_sets, fn, graph_types[0])
                            if file_path is not None:
                                images_list.append(file_path)
                                titles.append(fn)
                                link_urls.append(url_link)
                else:
                    url_link = dash_board_url+"plotcucm/?plot="+plot+"&start_date="+str(start_date)+"&end_date="+str(end_date)+"&cluster="+cluster
                    url_link = url_link.replace(" ", "%20")
                    data_sets = get_cucm_data(plot, cluster, start_date, end_date, None, None, None, mavg)
                    if data_sets:
                        file_path = get_file_path(data_sets, fn, graph_types[0])
                        if file_path is not None:
                            images_list.append(file_path)
                            titles.append(fn)
                            link_urls.append(url_link)
        else:
            #titles.append(fn)
            url_link = dash_board_url+"plotcucm/?plot="+plot+"&start_date="+str(start_date)+"&end_date="+str(end_date)
            url_link = url_link.replace(" ", "%20")
            data_sets = get_cucm_data(plot, None, start_date, end_date, None, None, None, mavg)
            if data_sets:
                file_path = get_file_path(data_sets, fn, graph_types[0])
                if file_path is not None:
                    images_list.append(file_path)
                    titles.append(fn)
                    link_urls.append(url_link)

def generate_desk_plots(plots,clusters,start_date,end_date):
    del titles[:]
    del link_urls[:]
    del images_list[:]
    for plot in plots:
        graph_types = get_graph_types(plot)
        if graph_types[0] == "BarLine":
            mavg = "True"
        else:
            mavg = "False"
        fn = plot
        if len(clusters)>0:
            for cluster in clusters:
                fn = plot +'_'+ cluster
                #titles.append(fn)
                data_sets = get_desk_data(plot, cluster, start_date, end_date, mavg)
                file_path = get_file_path(data_sets, fn, graph_types[0])
                if file_path is not None:
                    images_list.append(file_path)
                    url_link = dash_board_url+"plotdesk/?plot="+plot+"&start_date="+str(start_date)+"&end_date="+str(end_date)+"&cluster="+cluster
                    url_link = url_link.replace(" ", "%20")
                    link_urls.append(url_link)
                    titles.append(fn)
        else:
            #titles.append(fn)
            data_sets = get_desk_data(plot, None, start_date, end_date, mavg)
            file_path = get_file_path(data_sets, fn, graph_types[0])
            if file_path is not None:
                images_list.append(file_path)
                url_link = dash_board_url+"plotdesk/?plot="+plot+"&start_date="+str(start_date)+"&end_date="+str(end_date)
                url_link = url_link.replace(" ", "%20")
                link_urls.append(url_link)
                titles.append(fn)

def generate_cms_plots(plots,start_date,end_date):
    del titles[:]
    del link_urls[:]
    del images_list[:]
    for plot in plots:
        graph_types = get_graph_types(plot)
        if graph_types[0] == "BarLine":
            mavg = "True"
        else:
            mavg = "False"
        fn = plot
        #titles.append(fn)
        data_sets = get_cms_data(plot, start_date, end_date, mavg)
        file_path = get_file_path(data_sets, fn, graph_types[0])
        if file_path is not None:
            #postOnSpark(roomId, text, fn, file_path)
            images_list.append(file_path)
            url_link = dash_board_url+"plotcms/?plot="+plot+"&start_date="+str(start_date)+"&end_date="+str(end_date)
            url_link = url_link.replace(" ", "%20")
            link_urls.append(url_link)
            titles.append(fn)

def generate_hybridtest_plots(plots,start_date,end_date):
    del titles[:]
    del link_urls[:]
    del images_list[:]
    for plot in plots:
        graph_types = get_graph_types(plot)
        if graph_types[0] == "BarLine":
            mavg = "True"
        else:
            mavg = "False"
        fn = plot
        #titles.append(fn)
        data_sets = get_hybridtest_data(plot, start_date, end_date, mavg)
        file_path = get_file_path(data_sets, fn, graph_types[0])
        if file_path is not None:
            #postOnSpark(roomId, text, fn, file_path)
            images_list.append(file_path)
            url_link = dash_board_url+"plothybridtest/?plot="+plot+"&start_date="+str(start_date)+"&end_date="+str(end_date)
            url_link = url_link.replace(" ", "%20")
            link_urls.append(url_link)
            titles.append(fn)

def generate_plots_for_user_preferences(product, plots, clusters, versions, report_dest, report_fmt, dest_address):
    end_date = datetime.now().date()
    start_date = datetime.now().date()+timedelta(days=-90)
    file_name = product +'_'+ str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    #start_date = start_date.strftime("%Y-%m-%d")
    
    if product == "CUCM":
        generate_cucm_plots(plots, clusters, versions, start_date, end_date)
        if report_fmt == "PPT":
            cnt_type = "vnd.openxmlformats-officedocument.presentationml.presentation"
            file_path =pptx_generator(images_list, titles, link_urls, file_name)
            file_name = file_name+'.pptx'
        elif report_fmt == "PDF":
            cnt_type = "pdf"
            file_path = pdf_generator(images_list, titles, link_urls, file_name)
            file_name = file_name+'.pdf'
        if report_dest == "SPARKROOM":
            postOnSpark(dest_address, text, file_name, file_path,cnt_type)
    '''

    if product == "CMS":
        generate_cms_plots(plots, start_date, end_date)
        if report_fmt == "PPT":
            cnt_type = "vnd.openxmlformats-officedocument.presentationml.presentation"
            file_path =pptx_generator(images_list, titles, link_urls, file_name)
            file_name = file_name+'.pptx'
        elif report_fmt == "PDF":
            cnt_type = "pdf"
            file_path = pdf_generator(images_list, titles, link_urls, file_name)
            file_name = file_name+'.pdf'
        if report_dest == "SPARKROOM":
            postOnSpark(dest_address, text, file_name, file_path,cnt_type)

    
    if product == "DESK":
        generate_desk_plots(plots, clusters, start_date, end_date)
        if report_fmt == "PPT":
            cnt_type = "vnd.openxmlformats-officedocument.presentationml.presentation"
            file_path =pptx_generator(images_list, titles, link_urls, file_name)
            file_name = file_name+'.pptx'
        elif report_fmt == "PDF":
            cnt_type = "pdf"
            file_path = pdf_generator(images_list, titles, link_urls, file_name)
            file_name = file_name+'.pdf'
        if report_dest == "SPARKROOM":
            postOnSpark(dest_address, text, file_name, file_path,cnt_type)

    if product == "HYBRIDTEST":
        generate_hybridtest_plots(plots, start_date, end_date)
        if report_fmt == "PPT":
            cnt_type = "vnd.openxmlformats-officedocument.presentationml.presentation"
            file_path =pptx_generator(images_list, titles, link_urls, file_name)
            file_name = file_name+'.pptx'
        elif report_fmt == "PDF":
            cnt_type = "pdf"
            file_path = pdf_generator(images_list, titles, link_urls, file_name)
            file_name = file_name+'.pdf'
        if report_dest == "SPARKROOM":
            postOnSpark(dest_address, text, file_name, file_path,cnt_type)
    '''       
# accepts Account User key as param

@shared_task
def gen_plots(acct_user):
    pref_objs = UserPreferences.objects.filter(pref_type__name = "UI",account_user__key = acct_user)
    if pref_objs is not None and len(pref_objs)>0:
        reporting_obj = Reporting.objects.filter(account_user__key = acct_user)
        if reporting_obj is not None and len(reporting_obj)>0:
            report_dest = reporting_obj[0].destination_to_report.name
            report_fmt = reporting_obj[0].report_format.name
            dest_address = reporting_obj[0].destination_address
        for pref in pref_objs:
            versions = []
            clusters = []
            plots = []
            pref_mapping_objs = pref.pref_mappings.all()
            if pref_mapping_objs is not None and len(pref_mapping_objs)>0:
                for pref_map in pref_mapping_objs:
                    for cluster in pref_map.clusters.all():
                        if cluster.name not in clusters:
                            clusters.append(cluster.name)
                    for plot in pref_map.plots.all():
                        if plot.name not in plots:
                            plots.append(plot.name)
                    for version in pref_map.versions.all():
                        if version.name not in versions:
                            versions.append(version.name)
            generate_plots_for_user_preferences(pref.product.name, plots, clusters, versions, report_dest, report_fmt, dest_address)
    
@shared_task
def reporting_job_creation(report_key):
    reporting_obj = Reporting.objects.filter(key=report_key)
    if reporting_obj is not None and len(reporting_obj)>0:
        acct_usr = reporting_obj[0].account_user 
        time_schedule = reporting_obj[0].time_to_report
        if time_schedule:
            job_schedule = CrontabSchedule.objects.create(minute=time_schedule.minute,
                                                          hour=time_schedule.hour,
                                                          day_of_week = time_schedule.dayOfWeek, 
                                                          day_of_month=time_schedule.dayOfMonth,
                                                          month_of_year=time_schedule.month)
            
            task_name = str(acct_usr.account_user.username)+"_Reporting"
            job_task = PeriodicTask.objects.create(crontab = job_schedule,
                                           name = task_name,
                                           task = 'analytics.tasks.gen_plots',
                                           args = json.dumps([str(acct_usr.key)]))
            
            reporting_obj[0].task_obj = str(job_task.id)
            reporting_obj[0].save()
    
    
    