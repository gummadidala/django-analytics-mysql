from __future__ import division

import requests
from requests_toolbelt.multipart.encoder import MultipartEncoder
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.colors import pink, black, red, blue, green
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (Flowable, Paragraph, SimpleDocTemplate, Spacer)
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.rl_config import defaultPageSize
from reportlab.lib.utils import ImageReader
import copy
from pptx import Presentation
from pptx.util import Inches , Pt

def postOnSpark(roomId, text, file_name, file_path,cnt_type):
    spark_url = "https://api.ciscospark.com/v1/messages"
    text = text.replace(' ', '%20')
    #vnd.openxmlformats-officedocument.presentationml.presentation
    m = MultipartEncoder({'roomId': roomId,
                  'text': 'Please find the attachment',
                  'files': (file_name, open(file_path, 'rb'),
                  'application/'+cnt_type)})
    req_headers={"Content-type":m.content_type,"Authorization":"Bearer NzA1YmJlYjEtMmVlMy00MTNhLTk4MTMtOGI4ODA2ZThhNjFmMzA0ZmRjNjYtOTBi"}
    
    res  = requests.post(spark_url,data=m, headers=req_headers)
    print res.text
    return res

def pdf_generator(images, titles, link_urls, file_name):
    PAGE_HEIGHT=defaultPageSize[1]; PAGE_WIDTH=defaultPageSize[0]
    styles = getSampleStyleSheet()
    file_path = '/tmp/'+file_name+'.pdf'
    c  = canvas.Canvas(file_path)
    for i in range(len(images)):
        c.drawCentredString(PAGE_WIDTH/2.0, PAGE_HEIGHT-140, titles[i])
        c.drawImage(images[i],PAGE_WIDTH/2.0-290, PAGE_HEIGHT-550,600,400)
        r1 = (inch, 3*inch, 4*inch, 4.25*inch)
        c.linkURL(link_urls[i], r1, thickness=1, color=colors.white)
        c.drawString(inch+2, 4*inch+5, "Please click here for more information")
        c.showPage()
    c.save()
    return file_path

def pptx_generator(images, titles, link_urls, file_name):
    prs = Presentation()
    file_path = '/tmp/'+file_name+'.pptx'
    for i in range(len(images)):
        blank_slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(blank_slide_layout)
    
        left = Inches(4.5)
        top = Inches(0.2) 
        width = height = Inches(1)
        txBox = slide.shapes.add_textbox(left, top, width, height)
        tf = txBox.text_frame
        p = tf.add_paragraph()
        p.text = titles[i]
        p.font.size = Pt(15)
    
        left = Inches(4)
        top = Inches(6.5) 
        width = height = Inches(2)
        txBox = slide.shapes.add_textbox(left, top, width, height)
        tf = txBox.text_frame
        p = tf.add_paragraph()
        p.font.size = Pt(15)
        r = p.add_run()
        r.text = "Please click here for more information!"
        hlink = r.hyperlink
        hlink.address = link_urls[i]
        
        
        left = top = Inches(1)
        left = Inches(1)
        height = Inches(5.5)
        pic = slide.shapes.add_picture(images[i], left, top, height=height)
    
    prs.save(file_path)
    return file_path